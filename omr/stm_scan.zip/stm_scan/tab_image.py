"""Read printed guitar/bass TAB staves from page images (PDF prints from Guitar Pro, Ultimate Guitar,
Songsterr, MuseScore ...) and merge the fret numbers into the OMR result.

How it works:
1. All pages are stacked into one tall image, so a system split across two pages joins up again.
2. Staff lines are found by horizontal morphology; a group of 6 (or 4/5/7) evenly spaced lines whose
   spacing is clearly wider than the notation staves is a tab staff.
3. Fret numbers are the dark blobs sitting on a line; each digit is classified by a small
   nearest-neighbour model trained on digits rendered from common sans fonts (digits.py).
4. Vertical lines through the staff are bar lines.
5. Tab bars are aligned with the notation bars by pitch content, and each notated note gets its
   <string>/<fret>. Where tab and notation disagree on the pitch, the tab wins (it is printed as
   plain numbers, so it is the more reliable read) and the bar is reported.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import cv2
import numpy as np

STANDARD = {6: [64, 59, 55, 50, 45, 40], 4: [43, 38, 33, 28], 5: [43, 38, 33, 28, 23], 7: [64, 59, 55, 50, 45, 40, 35]}


@dataclass
class TabNumber:
    x: int
    string: int     # 1 = top line = highest string
    fret: int
    tied: bool = False


@dataclass
class TabBar:
    columns: list[list[TabNumber]] = field(default_factory=list)  # left to right, each a chord
    x0: int = 0
    x1: int = 0


@dataclass
class TabPage:
    bars: list[TabBar]
    strings: int


# ---------------------------------------------------------------- staff finding

def stack_pages(images: list[np.ndarray]) -> tuple[np.ndarray, list[int]]:
    """One tall image plus the y of each page break."""
    w = max(i.shape[1] for i in images)
    breaks = list(np.cumsum([i.shape[0] for i in images])[:-1])
    return np.vstack([np.pad(i, ((0, 0), (0, w - i.shape[1])), constant_values=255) for i in images]), breaks


def _join_across_breaks(groups, breaks):
    """A staff cut by a page break shows up as two short groups: the last lines of one page and the
    first lines of the next (with header/footer between). Join them when the spacing and width match."""
    out = []
    for g in groups:
        if out:
            prev = out[-1]
            if len(prev) >= 2 or len(g) >= 2:
                sp = float(np.median(np.diff([l[0] for l in (prev if len(prev) >= 2 else g)])))
                straddles = any(prev[-1][0] < b < g[0][0] for b in breaks)
                same_width = abs(prev[0][1] - g[0][1]) < 3 * sp and abs(prev[0][2] - g[0][2]) < 3 * sp
                if straddles and same_width and len(prev) + len(g) in (4, 5, 6, 7) and len(prev) < 6 and len(g) < 6:
                    # re-space the second part so the joined staff is evenly spaced
                    shift = prev[-1][0] + sp - g[0][0]
                    out[-1] = prev + [(l[0] + shift, l[1], l[2], l[0]) for l in g]
                    continue
        out.append(list(g))
    return out


def _lines(gray: np.ndarray):
    bw = ((gray < 215) * 255).astype(np.uint8)
    W = gray.shape[1]
    horiz = cv2.morphologyEx(bw, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (max(10, W // 40), 1)))
    rows = horiz.sum(1) / 255
    groups: list[list[int]] = []
    for y in np.where(rows > W * 0.25)[0]:
        if groups and y - groups[-1][-1] <= 2:
            groups[-1].append(int(y))
        else:
            groups.append([int(y)])
    lines = []
    for g in groups:
        xs = np.where(horiz[g[0]] > 0)[0]
        lines.append((int(np.mean(g)), int(xs.min()), int(xs.max())))
    return bw, horiz, lines


def _staves(lines, breaks=()):
    if not lines:
        return []
    staves, cur = [], [lines[0]]
    for a in lines[1:]:
        gap = a[0] - cur[-1][0]
        if len(cur) >= 2:
            sp = cur[-1][0] - cur[-2][0]
            ok = abs(gap - sp) <= max(3, 0.2 * sp)
        else:
            ok = gap < 80
        if ok:
            cur.append(a)
        else:
            staves.append(cur)
            cur = [a]
    staves.append(cur)
    staves = _join_across_breaks(staves, breaks)
    return [s for s in staves if len(s) >= 4]


def find_tab_staves(gray: np.ndarray, breaks=()):
    bw, horiz, lines = _lines(gray)
    groups = _staves(lines, breaks)
    if not groups:
        return bw, horiz, []
    sps = [float(np.median(np.diff([l[0] for l in g]))) for g in groups]
    five = [s for g, s in zip(groups, sps) if len(g) == 5]
    # a crooked photocopy can split each staff line in two, giving a "staff" at half the spacing:
    # ignore those, or every real staff looks wide enough to be tab (952 Our Father, 2026-11-26)
    if five:
        five = [s for s in five if s >= 0.7 * float(np.median(five))]
    notation_sp = min(five) if five else None
    tabs = []
    for g, sp in zip(groups, sps):
        n = len(g)
        wide = notation_sp is not None and sp > 1.2 * notation_sp
        is_tab = (n in (4, 6, 7) and (notation_sp is None or wide)) or (n == 5 and wide)
        if is_tab:
            real = [l[3] if len(l) > 3 else l[0] for l in g]
            if real != [l[0] for l in g]:
                # split staff: read each half separately with its own real line positions
                k = next(i for i, l in enumerate(g) if len(l) > 3)
                tabs.append(dict(ys=[l[0] for l in g], real=real, split=k,
                                 x0=min(l[1] for l in g), x1=max(l[2] for l in g), sp=sp))
            else:
                tabs.append(dict(ys=real, x0=min(l[1] for l in g), x1=max(l[2] for l in g), sp=sp))
    return bw, horiz, tabs


# ---------------------------------------------------------------- reading numbers

_reader = None


def _digit_reader():
    global _reader
    if _reader is None:
        from .digits import DigitReader
        _reader = DigitReader()
    return _reader


def read_staff(gray, bw, horiz, st) -> list[TabBar]:
    ys, sp = st["ys"], st["sp"]
    top, bot = max(0, int(ys[0] - sp * 0.6)), int(ys[-1] + sp * 0.6)
    xa, xb = st["x0"], st["x1"]
    sub = gray[top:bot, xa:xb]
    mask = bw[top:bot, xa:xb] > 0
    ink = int(np.percentile(sub[mask], 5)) if mask.any() else 0
    line_lvl = int(np.median(gray[ys[0], xa:xb]))
    if line_lvl - ink > 60:   # lines printed grey, numbers black: separate by darkness
        reg = ((sub < (ink + line_lvl) // 2) * 255).astype(np.uint8)
    else:                      # lines as dark as numbers: cut the lines out and heal the digits
        reg = bw[top:bot, xa:xb].copy()
        reg[horiz[top:bot, xa:xb] > 0] = 0
        reg = cv2.morphologyEx(reg, cv2.MORPH_CLOSE, np.ones((5, 1), np.uint8))
    vert = cv2.morphologyEx(bw[top:bot, xa:xb], cv2.MORPH_OPEN,
                            cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(5, int((ys[-1] - ys[0]) * 0.9)))))
    cols = np.where(vert.sum(0) > 0)[0]
    runs: list[list[int]] = []
    for c in cols:
        if runs and c - runs[-1][-1] <= 3:
            runs[-1].append(int(c))
        else:
            runs.append([int(c)])
    barx = [int(np.mean(r)) + xa for r in runs]
    if not barx or barx[0] - xa > 2 * sp:
        barx = [xa] + barx
    if xb - barx[-1] > 2 * sp:
        barx.append(xb)
    reg[vert > 0] = 0

    reader = _digit_reader()
    n, lab, stats, _ = cv2.connectedComponentsWithStats(reg, 8)
    digs = []
    for i in range(1, n):
        x, y, w, h, a = stats[i]
        if h < 0.4 * sp or h > 1.0 * sp or w > 0.9 * sp or a < 15:
            continue
        cy = y + h / 2 + top
        s = int(np.argmin([abs(cy - yy) for yy in ys]))
        if abs(cy - ys[s]) > 0.3 * sp:
            continue
        paren = w < 0.3 * h and h > 0.6 * sp
        d = None
        if not paren:
            d, _ = reader.read((lab[y:y + h, x:x + w] == i).astype(np.uint8) * 255)
        digs.append(dict(x=x + xa, x1=x + w + xa, s=s + 1, d=d, paren=paren))
    digs.sort(key=lambda c: (c["s"], c["x"]))
    nums: list[dict] = []
    for c in digs:
        p = nums[-1] if nums else None
        if p and p["s"] == c["s"] and c["x"] - p["x1"] < 0.3 * sp:
            p["x1"] = c["x1"]
            if c["paren"]:
                p["tied"] = True
            elif p["fret"] is None:
                p["fret"] = c["d"]
            elif p["fret"] < 3:  # frets go to 24; a third digit is noise
                p["fret"] = p["fret"] * 10 + c["d"]
        else:
            nums.append(dict(x=c["x"], x1=c["x1"], s=c["s"], fret=c["d"], tied=c["paren"]))
    found = [TabNumber(x=n["x"], string=n["s"], fret=n["fret"], tied=n["tied"]) for n in nums if n["fret"] is not None]
    found = [t for t in found if t.x > barx[0] + 0.8 * sp]  # skip the TAB clef letters

    bars = []
    for a, b in zip(barx, barx[1:]):
        inbar = sorted([t for t in found if a <= t.x < b], key=lambda t: t.x)
        columns: list[list[TabNumber]] = []
        for t in inbar:
            if columns and t.x - columns[-1][0].x < 0.5 * sp:
                columns[-1].append(t)
            else:
                columns.append([t])
        if columns or b - a > 3 * sp:
            bars.append(TabBar(columns=columns, x0=a, x1=b))
    return bars


def _unsplit(gray, bw, horiz, st):
    """Paste the two halves of a page-split staff together into a small image of their own."""
    sp, k, real = st["sp"], st["split"], st["real"]
    pad = int(sp)
    a0, a1 = int(real[0] - pad), int(real[k - 1] + sp / 2)
    b0, b1 = int(real[k] - sp / 2), int(real[-1] + pad)
    pieces = [gray[a0:a1], gray[b0:b1]]
    g2 = np.vstack(pieces)
    bw2, horiz2 = np.vstack([bw[a0:a1], bw[b0:b1]]), np.vstack([horiz[a0:a1], horiz[b0:b1]])
    ys = [y - a0 for y in real[:k]] + [y - b0 + (a1 - a0) for y in real[k:]]
    return g2, bw2, horiz2, dict(ys=ys, x0=st["x0"], x1=st["x1"], sp=sp)


def read_tab(images: list[np.ndarray]) -> TabPage | None:
    gray, breaks = stack_pages(images)
    bw, horiz, staves = find_tab_staves(gray, breaks)
    if not staves:
        return None
    strings = max(set(len(s["ys"]) for s in staves), key=[len(s["ys"]) for s in staves].count)
    for st in staves:
        # A staff one line short is usually cut off at the page edge (web-page prints do this):
        # add the missing bottom line.
        if len(st["ys"]) == strings - 1 and "split" not in st:
            st["ys"] = st["ys"] + [st["ys"][-1] + st["sp"]]
            st["clipped"] = True
    bars: list[TabBar] = []
    for st in staves:
        if len(st["ys"]) == strings:
            if "split" in st:
                bars.extend(read_staff(*_unsplit(gray, bw, horiz, st)))
            else:
                bars.extend(read_staff(gray, bw, horiz, st))
    return TabPage(bars=bars, strings=strings) if bars else None


# ---------------------------------------------------------------- merging with notation

def _align(a: list[list[int]], b: list[list[int]]):
    """Needleman-Wunsch over bars; similarity = overlap of sounding pitches."""
    def sim(x, y):
        if not x and not y:
            return 1.0
        sx, sy = sorted(x), sorted(y)
        common = len(set(sx) & set(sy))
        return 2 * common / (len(set(sx)) + len(set(sy)) or 1)
    n, m = len(a), len(b)
    gap = -0.4
    S = np.zeros((n + 1, m + 1))
    S[:, 0] = gap * np.arange(n + 1)
    S[0, :] = gap * np.arange(m + 1)
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            S[i, j] = max(S[i - 1, j - 1] + sim(a[i - 1], b[j - 1]), S[i - 1, j] + gap, S[i, j - 1] + gap)
    pairs, i, j = [], n, m
    while i > 0 and j > 0:
        if np.isclose(S[i, j], S[i - 1, j - 1] + sim(a[i - 1], b[j - 1])):
            pairs.append((i - 1, j - 1)); i -= 1; j -= 1
        elif np.isclose(S[i, j], S[i - 1, j] + gap):
            i -= 1
        else:
            j -= 1
    return pairs[::-1]


def merge_into_score(score, tab: TabPage, warnings: list[str], part=None) -> bool:
    """Attach string/fret to a part (default: the first) of a music21 score. Returns True if anything was merged."""
    import music21 as m21
    tuning = STANDARD.get(tab.strings, STANDARD[6])
    part = part if part is not None else score.parts[0]
    measures = list(part.getElementsByClass("Measure"))
    def events(meas):
        out = []
        for el in meas.recurse().notes:
            if el.tie is not None and el.tie.type in ("stop", "continue"):
                continue
            out.append(el)
        return sorted(out, key=lambda e: e.getOffsetInHierarchy(meas))
    nota = [[p.midi for e in events(mm) for p in e.pitches] for mm in measures]
    tabp = [[tuning[t.string - 1] + t.fret for col in b.columns for t in col] for b in tab.bars]
    pairs = _align(nota, tabp)
    merged, fixed, unmatched = 0, [], []
    for i, j in pairs:
        meas, bar = measures[i], tab.bars[j]
        evs = events(meas)
        cols = [c for c in bar.columns if not all(t.tied for t in c)]
        if len(evs) != len(cols):
            unmatched.append(meas.number)
            continue
        for ev, col in zip(evs, cols):
            notes = list(ev.notes) if ev.isChord else [ev]
            col = sorted(col, key=lambda t: t.string)            # high string first
            notes = sorted(notes, key=lambda nn: -nn.pitch.midi)  # high pitch first
            if len(notes) != len(col):
                unmatched.append(meas.number)
                break
            for nn, t in zip(notes, col):
                want = tuning[t.string - 1] + t.fret
                if nn.pitch.midi != want:
                    nn.pitch = m21.pitch.Pitch(midi=want)
                    if meas.number not in fixed:
                        fixed.append(meas.number)
                nn.articulations = [a for a in nn.articulations
                                    if not isinstance(a, (m21.articulations.StringIndication, m21.articulations.FretIndication))]
                nn.articulations.append(m21.articulations.StringIndication(t.string))
                nn.articulations.append(m21.articulations.FretIndication(t.fret))
                merged += 1
    if merged:
        warnings.append(f"Read the printed tab: {merged} notes got their string and fret from it "
                        f"(standard tuning assumed{'' if tab.strings == 6 else f', {tab.strings} strings'}).")
    if fixed:
        warnings.append("The tab corrected misread notes in bars " + ", ".join(map(str, fixed[:25]))
                        + ("..." if len(fixed) > 25 else "") + ".")
    if unmatched:
        u = sorted(set(unmatched))
        warnings.append("Tab and notation didn't line up in bars " + ", ".join(map(str, u[:25]))
                        + ("..." if len(u) > 25 else "") + "; those bars have no fingering.")
    return merged > 0


def staff_details_xml(strings: int) -> str:
    tuning = STANDARD.get(strings, STANDARD[6])
    names = [("C", 0), ("C", 1), ("D", 0), ("D", 1), ("E", 0), ("F", 0), ("F", 1), ("G", 0), ("G", 1), ("A", 0), ("A", 1), ("B", 0)]
    out = []
    for idx, midi in enumerate(reversed(tuning), start=1):
        st, al = names[midi % 12]
        out.append(f'<staff-tuning line="{idx}"><tuning-step>{st}</tuning-step>'
                   f"{'<tuning-alter>1</tuning-alter>' if al else ''}<tuning-octave>{midi // 12 - 1}</tuning-octave></staff-tuning>")
    return f"<staff-details><staff-lines>{strings}</staff-lines>{''.join(out)}</staff-details>"


# ---------------------------------------------------------------- score + tab prints with a vocal line

def erase_staves_without_tab(gray: np.ndarray) -> tuple[np.ndarray, int]:
    """In guitar score + tab prints, the notation staff that goes with the guitar sits right above
    its tab staff. Other notation staves (a vocal line shown on some systems only) make the music
    reader mix lines into the wrong part, so they are whited out, with the lyrics under them.
    Returns the cleaned page and how many staves were removed. Pages without tab are unchanged."""
    _, _, lines = _lines(gray)
    groups = _staves(lines)
    if len(groups) < 2:
        return gray, 0
    info = []
    for g in groups:
        ys = [l[0] for l in g]
        info.append(dict(top=ys[0], bottom=ys[-1], n=len(g), sp=float(np.median(np.diff(ys))),
                         x0=min(l[1] for l in g), x1=max(l[2] for l in g)))
    five = [s["sp"] for s in info if s["n"] == 5]
    if not five:
        return gray, 0
    nsp = float(np.median(five))
    for s in info:
        s["tab"] = s["sp"] > 1.2 * nsp and s["n"] in (4, 5, 6, 7)
    guitar = [i for i, s in enumerate(info[:-1]) if not s["tab"] and s["n"] == 5 and info[i + 1]["tab"]
              and info[i + 1]["top"] - s["bottom"] < 14 * nsp]
    if not guitar:
        return gray, 0   # no notation-above-tab pairs: not a score + tab print
    out = gray.copy()
    erased = 0
    H = gray.shape[0]
    for i, s in enumerate(info):
        if s["tab"] or s["n"] != 5 or i in guitar:
            continue
        nxt = info[i + 1]["top"] if i + 1 < len(info) else H
        prv = info[i - 1]["bottom"] if i else 0
        y0 = max(int(s["top"] - 4 * nsp), (prv + s["top"]) // 2)
        y1 = min(int(s["bottom"] + 4.5 * nsp), (s["bottom"] + nxt) // 2)
        x0 = max(0, s["x0"] - int(2 * nsp))
        out[y0:y1, x0:s["x1"] + int(nsp)] = 255
        erased += 1
    return out, erased
