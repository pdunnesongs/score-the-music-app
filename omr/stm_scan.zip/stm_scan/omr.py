"""Printed sheet music (photo, scan, PDF) -> MusicXML using the open-source homr engine.

homr (https://github.com/liebharc/homr, AGPL-3.0) reads printed standard notation:
notes, rests, chords, key and time signatures, multi-staff systems. It does NOT read
handwritten music, guitar tab staves, lyrics, dynamics or most articulations.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import logging
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff", ".heic"}
PDF_DPI = 300
log = logging.getLogger("stm.scan")
MAX_SIDE = 4000  # very large phone photos are scaled down before recognition


@dataclass
class OmrResult:
    musicxml: str
    pages: int
    warnings: list[str] = field(default_factory=list)


def _homr_cmd() -> list[str]:
    exe = shutil.which("homr")
    if exe:
        return [exe]
    return [sys.executable, "-m", "homr.main"]


def _prepare_image(src: Path, dst_dir: Path) -> Path:
    """Normalise a camera photo: fix EXIF rotation, convert to RGB PNG, cap the size."""
    from PIL import Image, ImageOps
    try:
        import pillow_heif  # optional, for iPhone photos
        pillow_heif.register_heif_opener()
    except ImportError:
        pass
    img = ImageOps.exif_transpose(Image.open(src)).convert("RGB")
    scale = MAX_SIDE / max(img.size)
    if scale < 1:
        img = img.resize((int(img.width * scale), int(img.height * scale)), Image.LANCZOS)
    out = dst_dir / (src.stem + ".png")
    img.save(out)
    return out


def _pdf_to_images(pdf: Path, dst_dir: Path) -> list[Path]:
    import pymupdf as fitz
    paths = []
    with fitz.open(pdf) as doc:
        for i, page in enumerate(doc, start=1):
            pix = page.get_pixmap(dpi=PDF_DPI, colorspace=fitz.csGRAY)
            p = dst_dir / f"page{i:03d}.png"
            pix.save(p)
            paths.append(p)
    return paths


GPU_ERROR = ("CUDNN", "CUDA", "cudnn", "cublas", "CUBLAS", "out of memory")


class OmrGpuError(RuntimeError):
    """The music reader failed on the graphics card (not the page's fault)."""


def _decode(b: bytes | None) -> str:
    """Text from the reader's output. On Windows some of it arrives as UTF-16 (onnxruntime's own
    messages), which read as UTF-8 put a space between every character in engine.log."""
    if not b:
        return ""
    if b.count(b"\x00") > len(b) // 4:
        try:
            return b.decode("utf-16-le", errors="replace").replace("\x00", "")
        except Exception:
            pass
    return b.decode("utf-8", errors="replace").replace("\x00", "")


def _homr_env(gpu: bool) -> dict:
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    if not gpu:
        # The page reader runs on the processor: on a PC with an NVIDIA card it otherwise picks CUDA,
        # whose half-precision networks can fail in cuDNN (Paul's RTX 4060 laptop, 2026-11-26), and
        # the card is busy with the audio models anyway. A page takes ~30 s on the processor.
        env["CUDA_VISIBLE_DEVICES"] = "-1"
    return env


def low_priority() -> dict:
    """subprocess options that run the page reader below normal priority. The PC reads library
    sheets in the background, one page reader process after another, each using every core: on
    b106 that ran alongside a song and its lyrics took 1859 s instead of 43 s. A song comes first."""
    if os.name == "nt":
        return {"creationflags": getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0x4000)
                | getattr(subprocess, "CREATE_NO_WINDOW", 0)}
    return {"preexec_fn": lambda: os.nice(10)}


def _run_homr(image: Path, timeout: int = 600) -> str:
    # STM_OMR_GPU=1 lets the page reader try the graphics card first (back to the processor if it fails)
    tries = [True, False] if os.environ.get("STM_OMR_GPU") == "1" else [False]
    tail = ""
    for gpu in tries:
        out = image.with_suffix(".musicxml")
        proc = subprocess.run(_homr_cmd() + ["--no-title", "--write-staff-positions", str(image)],
                              capture_output=True, timeout=timeout, cwd=image.parent, env=_homr_env(gpu),
                              **low_priority())
        if proc.returncode == 0 and out.exists():
            return out.read_text(encoding="utf-8")
        tail = (_decode(proc.stderr) or _decode(proc.stdout))[-4000:]
        if gpu and any(k in tail for k in GPU_ERROR):
            log.warning("Page reader failed on the graphics card, trying the processor: %s", tail[-600:])
            continue
        break
    if any(k in tail for k in GPU_ERROR):
        raise OmrGpuError(f"Music recognition failed on {image.name} (graphics card): {tail}")
    raise RuntimeError(f"Music recognition failed on {image.name}: {tail}")


def _skew_angle(gray) -> float:
    """How far a photographed page is turned, in degrees, from where its staff lines are flattest."""
    import cv2
    import numpy as np
    h, w = gray.shape
    k = 900 / max(w, 1)
    small = cv2.resize(gray, (int(w * k), int(h * k)), interpolation=cv2.INTER_AREA) if k < 1 else gray
    bw = cv2.adaptiveThreshold(small, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 31, 12)
    c = (bw.shape[1] / 2, bw.shape[0] / 2)

    def score(a: float) -> float:
        m = cv2.getRotationMatrix2D(c, a, 1.0)
        r = cv2.warpAffine(bw, m, (bw.shape[1], bw.shape[0]), flags=cv2.INTER_NEAREST)
        rows = r.sum(1).astype(np.float64)
        return float((rows ** 2).sum())

    best = max(np.arange(-4.0, 4.01, 0.25), key=score)
    return float(max(np.arange(best - 0.25, best + 0.251, 0.05), key=score))


def _straighten(image: Path) -> None:
    """Turn a slightly crooked photo level, so the staves and the words under them run straight."""
    import cv2
    gray = cv2.imread(str(image), cv2.IMREAD_GRAYSCALE)
    if gray is None:
        return
    a = _skew_angle(gray)
    if abs(a) < 0.3:
        return
    h, w = gray.shape
    m = cv2.getRotationMatrix2D((w / 2, h / 2), a, 1.0)
    cv2.imwrite(str(image), cv2.warpAffine(gray, m, (w, h), flags=cv2.INTER_CUBIC, borderValue=255))
    log.info("Straightened %s by %.2f degrees", image.name, a)


def _no_progress(step: str, fraction: float) -> None:
    pass


def recognise(path: str | os.PathLike, title: str | None = None, progress=None, melody_chords: bool = False) -> OmrResult:
    """Recognise an image or PDF of printed sheet music and return MusicXML.

    progress(step, fraction) is called as work goes on (fraction 0..1) for the app's status bar.
    melody_chords: also add a Melody part and chord names worked out from the printed parts, so a
    hymn or piano sheet plays as tune + chords (see melody_chords.py)."""
    progress = progress or _no_progress
    src = Path(path)
    ext = src.suffix.lower()
    warnings: list[str] = []
    with tempfile.TemporaryDirectory(prefix="stm-scan-") as tmp:
        tmpd = Path(tmp)
        progress("Preparing the pages", 0.03)
        if ext == ".pdf":
            images = _pdf_to_images(src, tmpd)
            if not images:
                raise ValueError("The PDF has no pages.")
        elif ext in IMAGE_EXTS:
            images = [_prepare_image(src, tmpd)]
        else:
            raise ValueError(f"Unsupported file type for scanning: {ext}")
        return recognise_images(images, title or src.stem, progress, melody_chords, warnings, src.name)


def recognise_images(images: list[Path], title: str, progress=None, melody_chords: bool = False,
                     warnings: list[str] | None = None, source_name: str = "scan") -> OmrResult:
    """Read prepared page images (greyscale PNGs, in a folder that may be written to). Also used by the
    phone's music reader, which runs this in the browser with homr in-process (_run_homr replaced)."""
    progress = progress or _no_progress
    warnings = [] if warnings is None else warnings
    n = len(images)
    for img in images:
        try:
            _straighten(img)
        except Exception as e:  # a bonus: read the page as it is
            log.warning("Couldn't straighten %s: %s", img.name, e)
    # Rough share of the time: pages 75%, tab 5%, chords+lyrics 12%, building the score 8%
    tab = None
    progress("Looking for printed tab", 0.06)
    try:
        from .tab_image import read_tab
        import cv2
        tab = read_tab([cv2.imread(str(i), cv2.IMREAD_GRAYSCALE) for i in images])
    except Exception as e:  # tab reading is a bonus; never fail the scan because of it
        warnings.append(f"Printed tab could not be read ({e}).")
    if tab is not None:
        # score + tab prints: white out notation staves with no tab under them (a vocal line on
        # some systems only), which otherwise get mixed into the guitar part
        from .tab_image import erase_staves_without_tab
        import cv2
        removed = 0
        for img in images:
            clean, k = erase_staves_without_tab(cv2.imread(str(img), cv2.IMREAD_GRAYSCALE))
            if k:
                cv2.imwrite(str(img), clean)
                removed += k
        if removed:
            warnings.append(f"Left out {removed} vocal or other staves that have no tab under them, "
                            "so only the guitar parts were read.")
    page_xmls = []
    crashed = 0   # pages the reader failed on for its own reasons (not "no staves on this page")
    text_pages, text_boxes = [], []
    for i, img in enumerate(images, start=1):
        progress(f"Reading page {i} of {n}" if n > 1 else "Reading the music", 0.08 + 0.72 * (i - 1) / n)
        try:
            page_xmls.append(_run_homr(img))
        except RuntimeError as e:
            # The full recogniser log goes to the engine's log, not to the person
            log.warning("Scan of %s, page %d failed: %s", source_name, i, e)
            if "No staffs found" not in str(e):
                crashed += 1
            if "No staffs found" in str(e):
                warnings.append(f"Page {i} has no music staves that could be found (a title or text page, or "
                                "too faint or small), so it was skipped.")
            else:
                warnings.append(f"Page {i} was skipped: the music reader stopped with an error on it "
                                "(the details are in the app's log).")
            continue
        boxes_file = img.with_suffix(".txt")
        if boxes_file.exists():
            import cv2
            text_pages.append(cv2.imread(str(img), cv2.IMREAD_GRAYSCALE))
            text_boxes.append([tuple(map(float, l.split()[1:5])) for l in boxes_file.read_text().splitlines() if l.strip()])
    text_systems = None
    if tab is None and text_pages:
        from .text_layers import read_text_layers, tesseract_available
        if tesseract_available():
            try:
                progress("Reading chord names and lyrics", 0.8)
                text_systems = read_text_layers(text_pages, text_boxes)
            except Exception as e:
                warnings.append(f"Chord names and lyrics could not be read ({e}).")
        else:
            warnings.append("Chord names and lyrics were skipped: the Tesseract OCR program isn't installed.")
    if not page_xmls:
        if crashed:
            # the reader itself failed: say so, rather than blaming the photo
            raise RuntimeError("The music reader on this device stopped with an error before it could read the "
                               "page (the details are in the app's log). This is a fault in the app, not your sheet.")
        raise RuntimeError("No music could be recognised. Try a sharper, flatter, well-lit photo.")
    progress("Building the score" + (" and matching the tab" if tab is not None else ""), 0.92)
    xml = page_xmls[0] if len(page_xmls) == 1 else _join_pages(page_xmls)
    xml = _postprocess(xml, title, warnings, tab, text_systems, melody_chords)
    progress("Done", 1.0)
    warnings.append("Recognised automatically: check it against the original. Dynamics, most "
                    "articulations and repeats/endings are not read yet.")
    return OmrResult(musicxml=xml, pages=len(images), warnings=warnings)


def _join_pages(xmls: list[str]) -> str:
    """Append the measures of each later page to the matching part of page one."""
    import music21 as m21
    scores = [m21.converter.parse(x, format="musicxml") for x in xmls]
    base = scores[0]
    for sc in scores[1:]:
        for i, part in enumerate(sc.parts):
            if i >= len(base.parts):
                base.insert(0, part)
                continue
            target = base.parts[i]
            offset = target.highestTime
            last_no = max((mm.number for mm in target.getElementsByClass("Measure")), default=0)
            for k, meas in enumerate(part.getElementsByClass("Measure"), start=1):
                meas.number = last_no + k
                target.insert(offset + meas.offset, meas)
    return _to_xml(base)


def _to_xml(score) -> str:
    import re
    from music21.musicxml.m21ToXml import GeneralObjectExporter
    xml = GeneralObjectExporter(score).parse().decode("utf-8")
    # music21 stamps itself in as the composer; drop that so the app doesn't show "Music21"
    xml = re.sub(r'\s*<creator type="composer">Music21</creator>', "", xml)
    xml = re.sub(r'\s*<movement-title>Music21 Fragment</movement-title>', "", xml)
    # music21 repeats the title as the movement title; drop the copy so it isn't shown twice
    m = re.search(r"<work-title>(.*?)</work-title>", xml)
    if m:
        xml = xml.replace(f"<movement-title>{m.group(1)}</movement-title>", "")
    return xml


def _postprocess(xml: str, title: str, warnings: list[str], tab=None, text_systems=None, melody_chords=False) -> str:
    """Name the parts, set a title, and flag bars whose lengths don't add up."""
    import music21 as m21
    score = m21.converter.parse(xml, format="musicxml")
    if score.metadata is None:
        score.insert(0, m21.metadata.Metadata())
    score.metadata.title = title
    # Tab staves under the notation (Guitar Pro / Ultimate Guitar prints) are sometimes read as an
    # extra staff of nothing but rests. Drop parts that are almost all empty bars.
    parts = list(score.parts)
    tab_dropped = False
    if len(parts) > 1:
        most = max(len(p.flatten().notes) for p in parts)
        for part in parts:
            measures = list(part.getElementsByClass("Measure"))
            filled = sum(1 for mm in measures if mm.flatten().notes)
            if measures and (filled / len(measures) < 0.2 or len(part.flatten().notes) < 0.1 * most):
                score.remove(part)
                tab_dropped = True
                warnings.append("Ignored a staff that looked like guitar tab or an empty line; "
                                "tab numbers are not read from images yet.")
    if tab is not None and not tab_dropped:
        tab_dropped = True  # the page has tab staves even if OMR ignored them
    if tab is not None and len(score.parts) > 1:
        # Every staff left is guitar notation (staves without tab were removed before reading);
        # some lines have a second guitar, read as an extra part.
        tab_dropped = True
    if tab_dropped and (len(score.parts) == 1 or tab is not None):
        # Notation printed above a tab staff is guitar music, written an octave above how it sounds.
        parts = sorted(score.parts, key=lambda p: -len(p.getElementsByClass("Measure")))
        for k, part in enumerate(parts):
            for inst in list(part.recurse().getElementsByClass("Instrument")):
                inst.activeSite.remove(inst)
            part.insert(0, m21.instrument.AcousticGuitar())
            part.partName = "Guitar" if k == 0 else f"Guitar {k + 1}"
            for clef in list(part.recurse().getElementsByClass("TrebleClef")):
                clef.activeSite.replace(clef, m21.clef.Treble8vbClef())
            for n in part.recurse().notes:  # MusicXML stores sounding pitch: an octave below the written note
                n.transpose("-P8", inPlace=True)
        warnings.append("Read as guitar because the page has tab under the notation (a guess).")
        if len(parts) > 1:
            warnings.append(f"{len(parts) - 1} extra guitar line(s) that only appear on some systems were read as "
                            "separate parts; their bars may not line up with the main guitar.")
        if tab is not None:
            from .tab_image import merge_into_score
            if merge_into_score(score, tab, warnings, part=parts[0]):
                warnings[:] = [w for w in warnings if not w.startswith("Ignored a staff that looked like guitar tab")]
    for i, part in enumerate(score.parts, start=1):
        # homr labels every part "Voice"; we can't tell the instrument from the page,
        # so default to piano (GUESS) and let the user change it in the app.
        if not part.partName or part.partName == "Voice":
            for inst in list(part.recurse().getElementsByClass("Instrument")):
                inst.activeSite.remove(inst)
            piano = m21.instrument.Piano()
            part.insert(0, piano)
            part.partName = "Piano" if len(score.parts) == 1 else f"Piano {i}"
            warnings.append(f"Instrument for '{part.partName}' is a guess (piano). Change it if needed.")
    if text_systems:
        from .text_layers import apply_text_layers
        try:
            apply_text_layers(score, text_systems, warnings)
        except Exception as e:
            warnings.append(f"Chord names and lyrics could not be placed ({e}).")
    if melody_chords and tab is None:
        from .melody_chords import add_melody_and_chords
        try:
            add_melody_and_chords(score, warnings)
        except Exception as e:  # a bonus: the score as read still plays
            log.warning("Melody and chords failed: %s", e, exc_info=True)
            warnings.append("The melody and chords couldn't be worked out from this sheet; it plays as printed.")
    bad = []
    for part in score.parts:
        ts = None
        measures = list(part.getElementsByClass("Measure"))
        for k, meas in enumerate(measures):
            ts = meas.timeSignature or ts
            # first and last bars are often short on purpose (pickup / final bar)
            if ts is None or k == 0 or k == len(measures) - 1:
                continue
            if abs(meas.duration.quarterLength - ts.barDuration.quarterLength) > 1e-6:
                bad.append(meas.number)
    if bad:
        uniq = sorted(set(bad))
        warnings.append("These bars don't add up to the time signature, so a note or rest was probably "
                        "misread: " + ", ".join(map(str, uniq[:20])) + ("..." if len(uniq) > 20 else "") + ".")
    xml = _to_xml(score)
    if tab is not None and "<fret>" in xml:
        import re
        from .tab_image import staff_details_xml
        xml = re.sub(r"(</clef>)", r"\1" + staff_details_xml(tab.strings), xml, count=1)
    return xml
