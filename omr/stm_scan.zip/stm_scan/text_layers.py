"""Chord names (above the staff) and lyrics (below it) for lead sheets and hymn books.

Uses the staff boxes homr finds, reads the text bands with Tesseract OCR, and attaches:
- lyrics: syllables in reading order to the melody notes in order (tied-over notes get none);
- chords: each chord name to the note whose syllable sits under it (nearest by x).
Only done for single-staff music (a melody line). Needs the `tesseract` program; without it the
scan still works and says chords and lyrics were skipped.
"""
from __future__ import annotations

import os
import re
import shutil
from dataclasses import dataclass

import cv2
import numpy as np

CHORD_RE = re.compile(r"^[A-G](#|b)?(m|min|maj|dim|aug|sus|add|M)?\d{0,2}(sus\d|add\d|b5|#5|b9|#9)?(/[A-G](#|b)?)?$")


@dataclass
class Word:
    x: int
    text: str
    y: int = 0  # top, height and width in band pixels (used to look for flat/sharp signs)
    h: int = 0
    w: int = 0


@dataclass
class Syllable:
    x: int
    text: str
    syllabic: str  # single | begin | middle | end
    extend: bool = False


def _find_tesseract() -> str | None:
    exe = shutil.which("tesseract")
    if exe:
        return exe
    # The Windows installers (UB Mannheim) don't add Tesseract to PATH.
    for base in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"),
                 os.environ.get("LOCALAPPDATA") and os.path.join(os.environ["LOCALAPPDATA"], "Programs"),
                 r"C:\Program Files", r"C:\Program Files (x86)"):
        if base:
            cand = os.path.join(base, "Tesseract-OCR", "tesseract.exe")
            if os.path.isfile(cand):
                return cand
    return None


def tesseract_available() -> bool:
    try:
        import pytesseract
    except ImportError:
        return False
    exe = _find_tesseract()
    if exe:
        pytesseract.pytesseract.tesseract_cmd = exe
    return exe is not None


def _ocr_words(band: np.ndarray, x_off: int, scale: float = 2.0, psm: int = 11, otsu: bool = True) -> list[Word]:
    import pytesseract
    if band.size == 0 or min(band.shape) < 4:
        return []
    img = cv2.resize(band, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    if otsu:
        img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    img = np.pad(img, 20, constant_values=255)
    d = pytesseract.image_to_data(img, config=f"--psm {psm}", output_type=pytesseract.Output.DICT)
    out = []
    for t, left, top, w, h, conf in zip(d["text"], d["left"], d["top"], d["width"], d["height"], d["conf"]):
        t = t.strip()
        if t and float(conf) > 10:
            out.append(Word(x=int((left - 20) / scale) + x_off, text=t, y=int((top - 20) / scale),
                            h=int(h / scale), w=int(w / scale)))
    return sorted(out, key=lambda w: w.x)


# ---------------------------------------------------------------- chords

_FIXES = [(r"^[Cc]c$", "C"), (r"^c$", "C"), (r"(?<=[A-G])mM", "m"), (r"(?<=[A-Gm#b])[Yy](?=[A-G])", "/"),
          (r"°", "6"), (r"[!|'’‘`\"?*]", "7"), (r"maj\?", "maj7"), (r"(?<=F)[tr+]", "#"), (r"(?<=C)[tr+]", "#"),
          (r"(?<=[A-G])I(?=[A-G])", "/"), (r"(?<=[A-G#b])I(?=[A-G])", "/"), (r"(?<=[A-G])M(?![a])", "m"),
          (r"(?<=[A-G#bm])/$", "7"), (r"[,.;:_]+$", ""), (r"^(?=[A-G])", "")]


def normalise_chord(t: str) -> str | None:
    t = t.replace("♯", "#").replace("♭", "b")
    for pat, rep in _FIXES:
        t = re.sub(pat, rep, t)
    return t if CHORD_RE.match(t) else None


def split_chords(t: str) -> list[str]:
    """'Am/GD/G' -> ['Am/G', 'D/G'] (two chords printed close together)."""
    whole = normalise_chord(t)
    if whole:
        return [whole]
    for i in range(1, len(t)):
        a, b = normalise_chord(t[:i]), normalise_chord(t[i:])
        if a and b:
            return [a, b]
    return []


# ---------------------------------------------------------------- lyrics

def to_syllables(words: list[Word]) -> list[Syllable]:
    """OCR words -> syllables. 'Fa - ther,' and 'in-to' are split; '__' extends the last syllable."""
    items: list[list] = []  # [x, text, continues, extend]
    for w in words:
        t = w.text.replace("–", "-")
        if set(t) <= set("-"):
            if items:
                items[-1][2] = True
            continue
        if set(t) <= set("_"):
            if items:
                items[-1][3] = True
            continue
        extend = t.endswith("_")
        t = t.rstrip("_")
        t = re.sub(r"^[^\w]+|[^\w,.;:!?']+$", "", t)
        if t[:1].isupper() and t[1:].islower() and len(t) > 1 and items and not items[-1][1].endswith((".", ";", ":", "!", "?")):
            t = t.lower()  # OCR often capitalises mid-line ('Is', 'Ses')
        if t.isupper() and len(t) > 1:
            t = t.lower()
        parts = t.split("-")
        for k, p in enumerate(parts):
            if p:
                items.append([w.x, p, k < len(parts) - 1, False])
            elif items and k == len(parts) - 1:
                items[-1][2] = True
        if extend and items:
            items[-1][3] = True
    out = []
    for i, (x, t, cont, ext) in enumerate(items):
        continued = i > 0 and items[i - 1][2]
        syl = {(False, False): "single", (False, True): "begin", (True, True): "middle", (True, False): "end"}[(continued, cont)]
        out.append(Syllable(x=x, text=t, syllabic=syl, extend=ext))
    return out


def _is_text(t: str) -> bool:
    return bool(re.search(r"[A-Za-z]", t)) or set(t) <= set("-–_")


# ---------------------------------------------------------------- main entry

def _text_line(words: list[Word], sp: float) -> list[Word]:
    """The one line of lyrics among words read from a band that also has notes in it: words of
    letter height and mostly letters, then those on the same line as most of them."""
    good = [w for w in words if 0.7 * sp <= w.h <= 2.6 * sp and sum(c.isalpha() for c in w.text) >= max(1, 0.6 * len(w.text))]
    if len(good) < 2:
        return []
    mids = sorted(w.y + w.h / 2 for w in good)
    best = max(mids, key=lambda m: sum(abs(x - m) <= 0.7 * sp for x in mids))
    return [w for w in good if abs(w.y + w.h / 2 - best) <= 0.9 * sp]


def _split_staves(img: np.ndarray, rect):
    """homr gives one box per system; a grand staff (hymn, piano) holds two staves with the words
    between them. Returns one box per 5-line staff found inside (the box itself if just one)."""
    import cv2
    from .tab_image import _staves
    x0, y0, x1, y1 = rect
    H = img.shape[0]
    pad = max(4, (y1 - y0) // 20)
    a, b = max(0, y0 - pad), min(H, y1 + pad)
    try:
        crop = img[a:b, max(0, x0):x1]
        # photos are unevenly lit: threshold against the neighbourhood, then keep long horizontal runs
        bw = cv2.adaptiveThreshold(crop, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 31, 12)
        W = crop.shape[1]
        horiz = cv2.morphologyEx(bw, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (max(10, W // 30), 1)))
        rows = horiz.sum(1) / 255
        runs: list[list[int]] = []
        for y in np.where(rows > W * 0.3)[0]:
            if runs and y - runs[-1][-1] <= 2:
                runs[-1].append(int(y))
            else:
                runs.append([int(y)])
        lines = [(int(np.mean(r)), 0, W) for r in runs]
        groups = [g for g in _staves(lines) if len(g) == 5]
    except Exception:
        return [rect]
    if len(groups) < 2:
        return [rect]
    return [(x0, a + g[0][0], x1, a + g[-1][0]) for g in groups]


def read_text_layers(pages: list[np.ndarray], boxes: list[list[tuple[float, float, float, float]]]):
    """Per staff in reading order: dict(chords=[(x, name)], syllables=[Syllable], sp, x0, x1)."""
    systems = []
    for img, bxs in zip(pages, boxes):
        H, W = img.shape
        rects = []
        for cx, cy, w, h in bxs:
            rects.append((int((cx - w / 2) * W), int((cy - h / 2) * H), int((cx + w / 2) * W), int((cy + h / 2) * H)))
        # (rect, place in its system: 0 = top staff, and how many staves the system has)
        split = []
        for big in sorted(rects, key=lambda r: r[1]):
            parts = _split_staves(img, big)
            split += [(r, i, len(parts)) for i, r in enumerate(parts)]
        rects = [r for r, _, _ in split]
        for k, ((x0, y0, x1, y1), place, of) in enumerate(split):
            sp = (y1 - y0) / 4
            prev_bottom = rects[k - 1][3] if k else 0
            next_top = rects[k + 1][1] if k + 1 < len(rects) else H
            top = max(0, int(y0 - 4.5 * sp), (prev_bottom + y0) // 2)
            if place + 1 < of:
                # words between the staves of a grand staff (hymns): the whole gap, then only the
                # line of text-sized words, as the inner voices' notes and stems sit there too
                bot = int(next_top - 0.8 * sp)
            else:
                bot = min(int(y1 + 4.0 * sp), (y1 + next_top) // 2 + int(sp))
            y_band = int(y1 + 0.8 * sp)
            below = [w for w in _ocr_words(img[y_band:bot, max(0, x0 - 10):x1 + 10], max(0, x0 - 10)) if _is_text(w.text)]
            if place + 1 < of:
                below = _text_line(below, sp)
            # a lower staff of a grand staff has no chord names of its own above it
            chords = [] if place else _read_chords(img[top:int(y0 - 0.6 * sp), max(0, x0 - 10):x1 + 10], max(0, x0 - 10), x0, sp)
            syl = to_syllables(below)
            systems.append(dict(chords=chords, syllables=syl, sp=sp, x0=x0, x1=x1))
    return systems


_ACC_OK_NEXT = set("mMdas123456789/(#b")


def _components(band: np.ndarray):
    """Ink blobs of a text band: (x, y, w, h, mask) in band pixels."""
    ink = cv2.threshold(band, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    n, lab, st, _ = cv2.connectedComponentsWithStats(ink, connectivity=8)
    out = []
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if a >= 6:
            out.append((int(x), int(y), int(w), int(h), (lab[y:y + h, x:x + w] == i).astype(np.uint8)))
    return out


def _holes(mask: np.ndarray) -> list[tuple[float, float, float, float]]:
    """Enclosed holes in a blob: centre x, centre y, width, height, all as fractions of the blob."""
    m = np.pad(mask, 1)
    cnts, hier = cv2.findContours(m, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    out = []
    if hier is None:
        return out
    h, w = mask.shape
    for c, hr in zip(cnts, hier[0]):
        if hr[3] >= 0 and cv2.contourArea(c) >= 2:
            x, y, cw, ch = cv2.boundingRect(c)
            out.append(((x - 1 + cw / 2) / w, (y - 1 + ch / 2) / h, cw / w, ch / h))
    return out


def classify_accidental(mask: np.ndarray, letter_h: int) -> str | None:
    """'b' for a flat sign, '#' for a sharp sign, else None. Flats and sharps are often a separate
    music-font glyph that OCR drops or reads as an apostrophe, so we look at the shape itself."""
    h, w = mask.shape
    if h < 0.5 * letter_h or h > 1.8 * letter_h or w > 1.1 * h:
        return None
    holes = _holes(mask)
    top = mask[: max(1, int(0.35 * h))]
    cols = top.any(axis=0)
    runs = int(cols[0]) + int(np.sum(cols[1:] & ~cols[:-1]))
    if w / h < 0.56 and runs == 1 and cols.nonzero()[0].max() < 0.45 * w \
            and any(hl[1] > 0.5 for hl in holes):
        return "b"
    row_runs = [int(r[0]) + int(np.sum(r[1:] & ~r[:-1])) for r in mask[: max(1, int(0.4 * h))].astype(bool)]
    bot_runs = [int(r[0]) + int(np.sum(r[1:] & ~r[:-1])) for r in mask[int(0.6 * h):].astype(bool)]
    two = sum(1 for r in row_runs if r >= 2) >= 0.5 * len(row_runs) and \
        sum(1 for r in bot_runs if r >= 2) >= 0.5 * max(1, len(bot_runs))
    # a sharp's hole is the small box in the middle of the grid; a 6 or 9 has a big round one
    if two and len(holes) == 1 and 0.3 < holes[0][1] < 0.7 and 0.3 < holes[0][0] < 0.7 \
            and holes[0][2] < 0.5 and holes[0][3] < 0.4 and w / h > 0.45:
        return "#"
    return None


def _fix_accidental(word: Word, x_off: int, comps, sp: float):
    """If the chord's root letter is followed by a flat/sharp sign, put it into the text.
    Returns (text, x_end_of_sign or None)."""
    t = word.text
    if not t or t[0] not in "ABCDEFG" or (len(t) > 1 and t[1] in "#b♭♯"):
        return t, None
    wx = word.x - x_off
    root = [c for c in comps if abs(c[0] - wx) <= max(3, 0.3 * sp) and c[3] >= 0.5 * max(word.h, 1)
            and c[1] <= word.y + word.h and c[1] + c[3] >= word.y]
    if not root:
        return t, None
    rx, ry, rw, rh, _ = min(root, key=lambda c: abs(c[0] - wx))
    nxt = [c for c in comps if rx + rw - 2 <= c[0] <= rx + rw + 0.6 * rh
           and c[1] < ry + rh and c[1] + c[3] > ry - 0.6 * rh]
    if not nxt:
        return t, None
    ax, ay, aw, ah, am = min(nxt, key=lambda c: c[0])
    acc = classify_accidental(am, rh)
    if not acc:
        return t, None
    rest = t[1:]
    if rest and rest[0] not in _ACC_OK_NEXT:
        rest = rest[1:]  # the sign misread as ' or F or *
    return t[0] + acc + rest, x_off + ax + aw


def _read_chords(band, x_off, staff_x0, sp):
    """Chord names are short and full of superscripts, so read the band three ways and vote."""
    comps = _components(band)
    cands = []
    for scale, psm, otsu in ((2, 11, True), (3, 11, False), (2, 6, False)):
        skip_to = -1
        for w in _ocr_words(band, x_off, scale, psm, otsu):
            if w.x < staff_x0 + 3.5 * sp:  # clef and key signature area
                continue
            if w.x < skip_to:  # the flat/sharp sign of the previous chord, read as its own word
                continue
            text, sign_end = _fix_accidental(w, x_off, comps, sp)
            if sign_end:
                skip_to = sign_end - 1
            names = split_chords(text)
            weight = 0.5 if text.endswith("/") else 1.0  # 'C/' is usually C7, but sometimes a 9
            for k, c in enumerate(names):
                cands.append((w.x + int(k * 2 * sp), c, weight))
    cands.sort()
    clusters: list[list] = []
    for x, c, wt in cands:
        if clusters and x - clusters[-1][-1][0] < 1.5 * sp:
            clusters[-1].append((x, c, wt))
        else:
            clusters.append([(x, c, wt)])
    out = []
    for cl in clusters:
        votes: dict[str, float] = {}
        for _, c, wt in cl:
            votes[c] = votes.get(c, 0) + wt
        best = max(votes, key=lambda n: (votes[n], len(n)))
        out.append((int(np.mean([x for x, _, _ in cl])), best))
    return out


def _system_measures(part):
    """Split the part's measures into systems using the new-system marks homr writes."""
    import music21 as m21
    groups: list[list] = []
    for mm in part.getElementsByClass("Measure"):
        new = any(getattr(sl, "isNew", False) for sl in mm.getElementsByClass(m21.layout.SystemLayout))
        if new or not groups:
            groups.append([])
        groups[-1].append(mm)
    return groups


def _top_line(mm):
    """The events of a staff with two voices (soprano and alto in a hymn) as one line: at each beat
    where something starts, the highest note (a rest only when nothing sounds there)."""
    at = {}
    for el in mm.recurse().notesAndRests:
        off = float(el.getOffsetInHierarchy(mm))
        cur = at.get(off)
        hi = max((p.midi for p in el.pitches), default=-1)
        if cur is None or hi > cur[0]:
            at[off] = (hi, el)
    return [el for _, (_, el) in sorted(at.items())]


def _estimate_x(measures, x0, x1, sp, top_line=False):
    """Rough x of each event in a system: engraved spacing grows with the log of the duration."""
    import math
    items = []  # (element, width)
    pos = 0.0
    xs = []
    for k, mm in enumerate(measures):
        pos += 1.5 if k else 0.0  # bar line padding
        for el in (_top_line(mm) if top_line else mm.recurse().notesAndRests):
            xs.append((el, pos, mm))
            d = max(float(el.quarterLength), 0.25)
            pos += max(0.7, 1.4 + 0.8 * math.log2(d))
    start = x0 + 4.5 * sp
    scale = (x1 - sp - start) / max(pos, 1e-6)
    return [(el, start + p * scale, mm) for el, p, mm in xs]


def _align(sylls, notes, sp):
    """Monotonic DP: match syllables to notes by x; either side may be skipped."""
    n, m = len(sylls), len(notes)
    skip_s, skip_n = 3.0, 1.2
    INF = 1e9
    D = np.full((n + 1, m + 1), INF)
    D[0, :] = np.arange(m + 1) * skip_n
    D[:, 0] = np.arange(n + 1) * skip_s
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            c = min(abs(sylls[i - 1].x - notes[j - 1][1]) / (4 * sp), 3.0)
            D[i, j] = min(D[i - 1, j - 1] + c, D[i - 1, j] + skip_s, D[i, j - 1] + skip_n)
    pairs, i, j = [], n, m
    while i > 0 and j > 0:
        c = min(abs(sylls[i - 1].x - notes[j - 1][1]) / (4 * sp), 3.0)
        if np.isclose(D[i, j], D[i - 1, j - 1] + c):
            pairs.append((i - 1, j - 1)); i -= 1; j -= 1
        elif np.isclose(D[i, j], D[i - 1, j] + skip_s):
            i -= 1
        else:
            j -= 1
    return pairs[::-1]


def apply_text_layers(score, systems, warnings: list[str]) -> None:
    import music21 as m21
    parts = list(score.parts)
    if not parts:
        return
    part = parts[0]
    groups = _system_measures(part)
    grand = False
    if len(parts) > 1:
        # a hymn or piano score: the words sit under the top staff of each system (between the
        # staves); the text read under every other staff is left out
        if not all(isinstance(p, m21.stream.PartStaff) for p in parts) or len(systems) != len(parts) * len(groups):
            return
        systems = systems[::len(parts)]
        grand = True
    if len(groups) != len(systems):
        warnings.append(f"Chord names and lyrics were skipped: found {len(systems)} staves but "
                        f"{len(groups)} lines of music.")
        return
    n_syl, n_left, n_chords, n_skip = 0, 0, 0, 0
    for sysd, measures in zip(systems, groups):
        sp = sysd["sp"]
        est = _estimate_x(measures, sysd["x0"], sysd["x1"], sp, top_line=grand)
        notes = [(el, x, mm) for el, x, mm in est if el.isNote or el.isChord]
        singable = [n for n in notes if not (n[0].tie is not None and n[0].tie.type in ("stop", "continue"))]
        sylls = sysd["syllables"]
        # If the counts agree, take them in order; otherwise align by position.
        pairs = list(zip(range(len(sylls)), range(len(singable)))) if len(sylls) == len(singable) \
            else _align(sylls, singable, sp)
        anchors = []
        for si, ni in pairs:
            el, _, mm = singable[ni]
            s = sylls[si]
            el.lyrics = [m21.note.Lyric(text=s.text, syllabic=s.syllabic)]
            anchors.append((s.x, el, mm))
            n_syl += 1
        n_left += len(sylls) - len(pairs)
        for x, name in sysd["chords"]:
            pool = anchors or [(nx, el, mm) for el, nx, mm in notes]
            if not pool:
                n_skip += 1
                continue
            _, el, meas = min(pool, key=lambda a: abs(a[0] - x))
            try:
                cs = m21.harmony.ChordSymbol(name)
            except Exception:
                n_skip += 1
                continue
            cs.writeAsChord = False
            # Show the name as printed (e.g. "m/G", "maj7/G"); many apps ignore <bass> otherwise.
            root_len = 2 if len(name) > 1 and name[1] in "#b" else 1
            cs.chordKindStr = name[root_len:]
            meas.insert(el.getOffsetBySite(el.activeSite) if el.activeSite is meas else el.getOffsetInHierarchy(meas), cs)
            n_chords += 1
    if n_syl and not grand and (part.partName or "").startswith("Piano"):
        # A single melody line with lyrics is a vocal line (lead sheet, hymn): don't call it piano.
        for inst in list(part.recurse().getElementsByClass("Instrument")):
            inst.activeSite.remove(inst)
        part.insert(0, m21.instrument.Vocalist())
        old = part.partName
        part.partName = "Voice"
        warnings[:] = [w for w in warnings if not w.startswith(f"Instrument for '{old}'")]
        warnings.append("Read as a vocal melody because it has lyrics (a guess). Change the instrument if needed.")
    if n_syl:
        warnings.append(f"Read {n_syl} lyric syllables" + (f" ({n_left} more words couldn't be matched to notes)" if n_left else "")
                        + ". Check that each sits under the right note.")
    if n_chords:
        from .backing import add_backing_chords
        add_backing_chords(score)
        warnings.append(f"Read {n_chords} chord names" + (f" ({n_skip} more couldn't be placed)" if n_skip else "")
                        + ". Chord reading is new: check the names, especially 7ths and slash chords.")
