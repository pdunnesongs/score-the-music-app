"""Chord names (above the staff) and lyrics (below it) for lead sheets and hymn books.

Uses the staff boxes homr finds, reads the text bands with Tesseract OCR, and attaches:
- lyrics: syllables in reading order to the melody notes in order (tied-over notes get none);
- chords: each chord name to the note whose syllable sits under it (nearest by x).
Only done for single-staff music (a melody line). Needs the `tesseract` program; without it the
scan still works and says chords and lyrics were skipped.
"""
from __future__ import annotations

import os
import re
import shutil
from dataclasses import dataclass

import cv2
import numpy as np

CHORD_RE = re.compile(r"^[A-G](#|b)?(m|min|maj|dim|aug|sus|add|M)?\d{0,2}(sus\d|add\d|b5|#5|b9|#9)?(/[A-G](#|b)?)?$")


@dataclass
class Word:
    x: int
    text: str
    y: int = 0  # top, height and width in band pixels (used to look for flat/sharp signs)
    h: int = 0
    w: int = 0


@dataclass
class Syllable:
    x: int
    text: str
    syllabic: str  # single | begin | middle | end
    extend: bool = False


def _find_tesseract() -> str | None:
    exe = shutil.which("tesseract")
    if exe:
        return exe
    # The Windows installers (UB Mannheim) don't add Tesseract to PATH.
    for base in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"),
                 os.environ.get("LOCALAPPDATA") and os.path.join(os.environ["LOCALAPPDATA"], "Programs"),
                 r"C:\Program Files", r"C:\Program Files (x86)"):
        if base:
            cand = os.path.join(base, "Tesseract-OCR", "tesseract.exe")
            if os.path.isfile(cand):
                return cand
    return None


def tesseract_available() -> bool:
    try:
        import pytesseract
    except ImportError:
        return False
    exe = _find_tesseract()
    if exe:
        pytesseract.pytesseract.tesseract_cmd = exe
    return exe is not None


def _ocr_words(band: np.ndarray, x_off: int, scale: float = 2.0, psm: int = 11, otsu: bool = True) -> list[Word]:
    import pytesseract
    if band.size == 0 or min(band.shape) < 4:
        return []
    img = cv2.resize(band, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    if otsu:
        img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    img = np.pad(img, 20, constant_values=255)
    d = pytesseract.image_to_data(img, config=f"--psm {psm}", output_type=pytesseract.Output.DICT)
    out = []
    for t, left, top, w, h, conf in zip(d["text"], d["left"], d["top"], d["width"], d["height"], d["conf"]):
        t = t.strip()
        if t and float(conf) > 10:
            out.append(Word(x=int((left - 20) / scale) + x_off, text=t, y=int((top - 20) / scale),
                            h=int(h / scale), w=int(w / scale)))
    return sorted(out, key=lambda w: w.x)


# ---------------------------------------------------------------- chords

_FIXES = [(r"^[Cc]c$", "C"), (r"^c$", "C"), (r"(?<=[A-G])mM", "m"), (r"(?<=[A-Gm#b])[Yy](?=[A-G])", "/"),
          (r"°", "6"), (r"[!|'’‘`\"?*]", "7"), (r"maj\?", "maj7"), (r"(?<=F)[tr+]", "#"), (r"(?<=C)[tr+]", "#"), (r"(?<=^[A-G])[&$%£¢§](?=m|\d|$|/)", "#"),
          (r"(?<=^[CDFGA])e(?=m)", "#"),
          (r"(?<=[A-G])I(?=[A-G])", "/"), (r"(?<=[A-G#b])I(?=[A-G])", "/"), (r"(?<=[A-G])M(?![a])", "m"),
          (r"(?<=[A-G#bm])/$", "7"), (r"^(?=[A-G]>)", ""), (r"(?<=^[A-G])>", "b"), (r"[,.;:_]+$", ""), (r"^(?=[A-G])", "")]


def m21_figure(name: str) -> str:
    """music21 writes flats as '-': 'Eb' fails and 'Bb7' turns into B7, so 'Bb7/Eb' -> 'B-7/E-'."""
    return re.sub(r"(^|/)([A-G])b", r"\1\2-", name)


def normalise_chord(t: str) -> str | None:
    t = t.replace("♯", "#").replace("♭", "b")
    for pat, rep in _FIXES:
        t = re.sub(pat, rep, t)
    return t if CHORD_RE.match(t) else None


def split_chords(t: str) -> list[str]:
    """'Am/GD/G' -> ['Am/G', 'D/G'] (two chords printed close together)."""
    whole = normalise_chord(t)
    if whole:
        return [whole]
    for i in range(1, len(t)):
        a, b = normalise_chord(t[:i]), normalise_chord(t[i:])
        if a and b:
            return [a, b]
    return []


# ---------------------------------------------------------------- lyrics

def to_syllables(words: list[Word]) -> list[Syllable]:
    """OCR words -> syllables. 'Fa - ther,' and 'in-to' are split; '__' extends the last syllable."""
    items: list[list] = []  # [x, text, continues, extend]
    # specks read as words: much smaller than the rest, or sitting on top of the word before
    hs = sorted(w.h for w in words if w.h and re.search(r"[A-Za-z]{2}", w.text))
    mh = hs[len(hs) // 2] if hs else 0
    kept: list[Word] = []
    for w in sorted(words, key=lambda w: w.x):
        if mh and w.h and w.h < 0.55 * mh:
            continue
        core = re.sub(r"[^A-Za-z]", "", w.text)
        if core and len(core) <= 3 and not re.search(r"[aeiouyAEIOUY]", core) and core not in ("I", "s"):
            continue    # no vowel: a speck or a dash read as letters ('ld', 'lv')
        if kept and kept[-1].w and w.x < kept[-1].x + 0.6 * kept[-1].w and len(w.text) <= len(kept[-1].text):
            continue
        kept.append(w)
    for w in kept:
        t = w.text.replace("–", "-")
        if set(t) <= set("-"):
            if items:
                items[-1][2] = True
            continue
        if set(t) <= set("_"):
            if items:
                items[-1][3] = True
            continue
        extend = t.endswith("_")
        t = t.rstrip("_")
        t = re.sub(r"^[^\w]+|[^\w,.;:!?']+$", "", t)
        t = re.sub(r"(?<=\w):$", "", t)   # 'let:' (a speck by the word); hymns hardly use colons
        if t[:1].isupper() and t[1:].islower() and len(t) > 1 and items and not items[-1][1].endswith((".", ";", ":", "!", "?")):
            t = t.lower()  # OCR often capitalises mid-line ('Is', 'Ses')
        if t.isupper() and len(t) > 1:
            t = t.lower()
        parts = t.split("-")
        for k, p in enumerate(parts):
            if p:
                items.append([w.x, p, k < len(parts) - 1, False])
            elif items and k == len(parts) - 1:
                items[-1][2] = True
        if extend and items:
            items[-1][3] = True
    out = []
    for i, (x, t, cont, ext) in enumerate(items):
        continued = i > 0 and items[i - 1][2]
        syl = {(False, False): "single", (False, True): "begin", (True, True): "middle", (True, False): "end"}[(continued, cont)]
        out.append(Syllable(x=x, text=t, syllabic=syl, extend=ext))
    return out


def _is_text(t: str) -> bool:
    return bool(re.search(r"[A-Za-z]", t)) or set(t) <= set("-–_")


# ---------------------------------------------------------------- main entry

def _text_line(words: list[Word], sp: float) -> list[Word]:
    """The one line of lyrics among words read from a band that also has notes in it: words of
    letter height and mostly letters, then those on the same line as most of them."""
    good = [w for w in words if 0.7 * sp <= w.h <= 2.6 * sp and sum(c.isalpha() for c in w.text) >= max(1, 0.6 * len(w.text))]
    if len(good) < 2:
        return []
    mids = sorted(w.y + w.h / 2 for w in good)
    best = max(mids, key=lambda m: sum(abs(x - m) <= 0.7 * sp for x in mids))
    return [w for w in good if abs(w.y + w.h / 2 - best) <= 0.9 * sp]


def _split_staves(img: np.ndarray, rect):
    """homr gives one box per system; a grand staff (hymn, piano) holds two staves with the words
    between them. Returns one box per 5-line staff found inside (the box itself if just one)."""
    import cv2
    from .tab_image import _staves
    x0, y0, x1, y1 = rect
    H = img.shape[0]
    pad = max(4, (y1 - y0) // 20)
    a, b = max(0, y0 - pad), min(H, y1 + pad)
    try:
        crop = img[a:b, max(0, x0):x1]
        # photos are unevenly lit: threshold against the neighbourhood, then keep long horizontal runs
        bw = cv2.adaptiveThreshold(crop, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 31, 12)
        W = crop.shape[1]
        horiz = cv2.morphologyEx(bw, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (max(10, W // 30), 1)))
        rows = horiz.sum(1) / 255
        runs: list[list[int]] = []
        for y in np.where(rows > W * 0.3)[0]:
            if runs and y - runs[-1][-1] <= 2:
                runs[-1].append(int(y))
            else:
                runs.append([int(y)])
        lines = [(int(np.mean(r)), 0, W) for r in runs]
        groups = [g for g in _staves(lines) if len(g) == 5]
    except Exception:
        return [rect]
    if len(groups) < 2:
        return [rect]
    return [(x0, a + g[0][0], x1, a + g[-1][0]) for g in groups]


def _song_heading(gap: np.ndarray, sp: float) -> bool:
    """True when the space between two lines of music holds the next song's heading: a hymnal
    number in large print ("814 With a song in our hearts" under 813 on the same page)."""
    if gap.size == 0 or gap.shape[0] < 6 * sp:
        return False
    for w in _ocr_words(gap, 0, 1.0 if sp > 15 else 2.0, 11, True):
        if re.match(r"^\d{2,4}[a-z]?$", w.text) and w.h >= 1.3 * sp:
            return True
    return False


def read_text_layers(pages: list[np.ndarray], boxes: list[list[tuple[float, float, float, float]]]):
    """Per staff in reading order: dict(chords=[(x, name)], syllables=[Syllable], sp, x0, x1)."""
    systems = []
    for img, bxs in zip(pages, boxes):
        H, W = img.shape
        rects = []
        for cx, cy, w, h in bxs:
            rects.append((int((cx - w / 2) * W), int((cy - h / 2) * H), int((cx + w / 2) * W), int((cy + h / 2) * H)))
        # (rect, place in its system: 0 = top staff, and how many staves the system has)
        split = []
        for big in sorted(rects, key=lambda r: r[1]):
            parts = _split_staves(img, big)
            split += [(r, i, len(parts)) for i, r in enumerate(parts)]
        rects = [r for r, _, _ in split]
        for k, ((x0, y0, x1, y1), place, of) in enumerate(split):
            sp = (y1 - y0) / 4
            prev_bottom = rects[k - 1][3] if k else 0
            next_top = rects[k + 1][1] if k + 1 < len(rects) else H
            top = max(0, int(y0 - 4.5 * sp), (prev_bottom + y0) // 2)
            new_song = bool(k and not place and _song_heading(img[prev_bottom + int(sp):max(prev_bottom + int(sp), y0 - int(sp))], sp))
            if place + 1 < of:
                # words between the staves of a grand staff (hymns): the whole gap, then only the
                # line of text-sized words, as the inner voices' notes and stems sit there too
                bot = int(next_top - 0.8 * sp)
            else:
                bot = min(int(y1 + 4.0 * sp), (y1 + next_top) // 2 + int(sp))
            y_band = int(y1 + 0.8 * sp)
            below = [w for w in _ocr_words(img[y_band:bot, max(0, x0 - 10):x1 + 10], max(0, x0 - 10)) if _is_text(w.text)]
            if place + 1 < of:
                below = _text_line(below, sp)
            # a lower staff of a grand staff has no chord names of its own above it
            if not place:
                # two rows of chord names (as sounding, and the capo shapes in brackets) reach
                # higher: if ink runs into the top of the band, look further up
                edge = img[top:top + max(2, int(0.15 * sp)), max(0, x0 - 10):x1 + 10]
                if edge.size and (edge < 128).mean() > 0.002:
                    top = max(0, int(y0 - 6.5 * sp), (prev_bottom + y0) // 2)
            bottom = int(y0 - 0.6 * sp)
            if not place:
                # names printed close to the staff (Gloria) are cut by the usual edge: if a line
                # of text runs into it, take a little more
                rows = _text_rows(img[top:bottom, max(0, x0 - 10):x1 + 10], sp)
                if rows and rows[-1][1] >= bottom - top - 1:
                    bottom = int(y0 - 0.3 * sp)
            near = img[int(y0 - 0.25 * sp):max(int(y0 - 0.25 * sp) + 1, int(y0 - 0.05 * sp)), max(0, x0 - 10):x1 + 10]
            chords, shapes = ([], None) if place else _read_chords(img[top:bottom, max(0, x0 - 10):x1 + 10], max(0, x0 - 10), x0, sp, near)
            syl = to_syllables(below)
            systems.append(dict(chords=chords, syllables=syl, sp=sp, x0=x0, x1=x1, shapes=shapes, new_song=new_song))
    # capo shapes in brackets: one capo for the song, from every line's pairs together
    steps: dict[int, float] = {}
    for sd in systems:
        for d, n in ((sd["shapes"] or {}).get("steps") or {}).items():
            steps[d] = steps.get(d, 0) + n
    capo = _pick_capo(steps)
    for sd in systems:
        info = sd.pop("shapes")
        sd["capo"] = capo if info else None
        if capo and info:
            sd["chords"] = _with_capo(sd["chords"], info, capo)
    for _ in range(2):      # twice: a mark named in one line can name its neighbour in another
        if not _fill_unread(systems):
            break
    for sd in systems:
        sd["chords"] = [(x, n) for x, n in sd["chords"] if n]
    return systems


_ACC_OK_NEXT = set("mMdas123456789/(#b")


def _components(band: np.ndarray):
    """Ink blobs of a text band: (x, y, w, h, mask) in band pixels."""
    ink = cv2.threshold(band, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    n, lab, st, _ = cv2.connectedComponentsWithStats(ink, connectivity=8)
    out = []
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if a >= 6:
            out.append((int(x), int(y), int(w), int(h), (lab[y:y + h, x:x + w] == i).astype(np.uint8)))
    return out


def _holes(mask: np.ndarray) -> list[tuple[float, float, float, float]]:
    """Enclosed holes in a blob: centre x, centre y, width, height, all as fractions of the blob."""
    m = np.pad(mask, 1)
    cnts, hier = cv2.findContours(m, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    out = []
    if hier is None:
        return out
    h, w = mask.shape
    for c, hr in zip(cnts, hier[0]):
        if hr[3] >= 0 and cv2.contourArea(c) >= 2:
            x, y, cw, ch = cv2.boundingRect(c)
            out.append(((x - 1 + cw / 2) / w, (y - 1 + ch / 2) / h, cw / w, ch / h))
    return out


def classify_accidental(mask: np.ndarray, letter_h: int) -> str | None:
    """'b' for a flat sign, '#' for a sharp sign, else None. Flats and sharps are often a separate
    music-font glyph that OCR drops or reads as an apostrophe, so we look at the shape itself."""
    h, w = mask.shape
    if h < 0.5 * letter_h or h > 1.8 * letter_h or w > 1.1 * h:
        return None
    holes = _holes(mask)
    top = mask[: max(1, int(0.35 * h))]
    cols = top.any(axis=0)
    runs = int(cols[0]) + int(np.sum(cols[1:] & ~cols[:-1]))
    if w / h < 0.56 and runs == 1 and cols.nonzero()[0].max() < 0.45 * w \
            and any(hl[1] > 0.5 for hl in holes):
        return "b"
    row_runs = [int(r[0]) + int(np.sum(r[1:] & ~r[:-1])) for r in mask[: max(1, int(0.4 * h))].astype(bool)]
    bot_runs = [int(r[0]) + int(np.sum(r[1:] & ~r[:-1])) for r in mask[int(0.6 * h):].astype(bool)]
    two = sum(1 for r in row_runs if r >= 2) >= 0.5 * len(row_runs) and \
        sum(1 for r in bot_runs if r >= 2) >= 0.5 * max(1, len(bot_runs))
    # a sharp's hole is the small box in the middle of the grid; a 6 or 9 has a big round one
    if two and len(holes) == 1 and 0.3 < holes[0][1] < 0.7 and 0.3 < holes[0][0] < 0.7 \
            and holes[0][2] < 0.5 and holes[0][3] < 0.4 and w / h > 0.45:
        return "#"
    return None


def _fix_accidental(word: Word, x_off: int, comps, sp: float):
    """If the chord's root letter is followed by a flat/sharp sign, put it into the text.
    Returns (text, x_end_of_sign or None)."""
    t = word.text
    if not t or t[0] not in "ABCDEFG" or (len(t) > 1 and t[1] in "#b♭♯"):
        return t, None
    wx = word.x - x_off
    root = [c for c in comps if abs(c[0] - wx) <= max(3, 0.3 * sp) and c[3] >= 0.5 * max(word.h, 1)
            and c[1] <= word.y + word.h and c[1] + c[3] >= word.y]
    if not root:
        return t, None
    rx, ry, rw, rh, _ = min(root, key=lambda c: abs(c[0] - wx))
    nxt = [c for c in comps if rx + rw - 2 <= c[0] <= rx + rw + 0.6 * rh
           and c[1] < ry + rh and c[1] + c[3] > ry - 0.6 * rh]
    if not nxt:
        return t, None
    ax, ay, aw, ah, am = min(nxt, key=lambda c: c[0])
    acc = classify_accidental(am, rh)
    if not acc:
        return t, None
    rest = t[1:]
    if rest and rest[0] not in _ACC_OK_NEXT:
        rest = rest[1:]  # the sign misread as ' or F or *
    return t[0] + acc + rest, x_off + ax + aw


PRINTED_CAPO = "printed-capo"     # <miscellaneous-field> read by the app (src/keyLocal.ts)
SHARP_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
FLAT_NAMES = ["C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B"]
_PC = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def _split_name(name: str):
    """'Bb7/F' -> (10, '7', 5); None if it isn't a chord name."""
    m = re.match(r"^([A-G])([#b]?)(.*?)(?:/([A-G])([#b]?))?$", name)
    if not m:
        return None
    acc = {"#": 1, "b": -1, "": 0}
    root = (_PC[m.group(1)] + acc[m.group(2)]) % 12
    bass = None if not m.group(4) else (_PC[m.group(4)] + acc[m.group(5)]) % 12
    return root, m.group(3), bass


def _name_up(shape: str, capo: int, like: str | None) -> str | None:
    """The chord that sounds when the shape is played with the capo at this fret. Black keys are
    spelt with flats (capo keys are mostly Eb, Ab, Bb, F) unless the printed name used sharps."""
    sp = _split_name(shape)
    if sp is None:
        return None
    root, suffix, bass = sp
    names = SHARP_NAMES if like and "#" in like and "b" not in like[1:2] else FLAT_NAMES
    out = names[(root + capo) % 12] + suffix
    if bass is not None:
        out += "/" + names[(bass + capo) % 12]
    return out


def _from_pair(shape: str, capo: int, printed: str | None) -> str | None:
    """One chord from a shape and the name printed with it. The printed name wins when it reads
    cleanly with its sign (a '#' in a shape is easily lost: (F#m) read as (Fm)) or agrees on the
    root; a plain letter that doesn't agree is usually a lost flat (E for Eb) or a misprint."""
    up = _name_up(shape, capo, printed)
    p, u = _split_name(printed) if printed else None, _split_name(up) if up else None
    if p is None:
        return up
    if u is None:
        return printed
    if p[0] == u[0]:
        return printed if len(printed) >= len(up) else up   # the fuller of the two (Bbadd9/D)
    # a semitone apart: the shape lost its sign ((F#m) read as (Fm)) and the printed name is right
    return printed if (p[0] - u[0]) % 12 in (1, 11) and re.search(r"[#b]", printed) else up


_SHAPE = re.compile(r"\(([^()]+)\)?|^([^()]+)\)")


def _text_rows(band, sp):
    """(top, bottom) of each line of text in a chord band."""
    if band.size == 0:
        return []
    ink = cv2.threshold(band, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    on = (ink > 0).sum(1) > 0.01 * band.shape[1]
    rows, st = [], None
    for y, v in enumerate(on):
        if v and st is None:
            st = y
        elif not v and st is not None:
            rows.append((st, y))
            st = None
    if st is not None:
        rows.append((st, len(on)))
    return [r for r in rows if 0.4 * sp <= r[1] - r[0] <= 2.2 * sp]


def _vote(cands, sp, gap=1.5):
    """Cluster readings by position and keep the name most passes agree on."""
    cands.sort()
    clusters: list[list] = []
    for x, c, wt in cands:
        if clusters and x - clusters[-1][-1][0] < gap * sp:
            clusters[-1].append((x, c, wt))
        else:
            clusters.append([(x, c, wt)])
    out = []
    for cl in clusters:
        votes: dict[str, float] = {}
        for _, c, wt in cl:
            votes[c] = votes.get(c, 0) + wt
        best = max(votes, key=lambda n: (votes[n], len(n)))
        out.append((int(np.mean([x for x, _, _ in cl])), best))
    return out


def _unread(comps, named, concert, x_off, sp, band_h, staff_x0):
    """Marks in the row of chord names that no pass could read (a thin 'D⁷' read as '1)?'):
    (x, None), filled in later from the same run of chords elsewhere in the song."""
    if len(named) < 2:
        return []
    cy = float(np.median([w.y + w.h / 2 for w in named]))
    ch = float(np.median([w.h for w in named]))
    # not marks that run off the bottom of the band: the top of a clef, key signature or stem
    blobs = sorted((c for c in comps if abs(c[1] + c[3] / 2 - cy) < 0.6 * ch and 0.4 * ch <= c[3] <= 1.6 * ch
                    and c[1] + c[3] < band_h - 2 and c[0] + x_off >= staff_x0 + 3.5 * sp), key=lambda c: c[0])
    groups: list[list] = []
    for c in blobs:
        if groups and c[0] - (groups[-1][-1][0] + groups[-1][-1][2]) < 0.6 * sp:
            groups[-1].append(c)
        else:
            groups.append([c])
    out = []
    for g in groups:
        x0, x1 = g[0][0] + x_off, max(c[0] + c[2] for c in g) + x_off
        if not (0.5 * sp <= x1 - x0 <= 3.5 * sp):
            continue      # a speck, or a line of words ("cue size notes in v. 3")
        if any(x0 - 1.0 * sp <= x <= x1 + 0.5 * sp for x, _ in concert):
            continue
        out.append((x0, None))
    return out


def _fill_unread(systems) -> int:
    """Name the unread marks from another line with the same chords either side: a hymn's
    refrain repeats (Gloria: 'Em Am ? G' and later 'Em Am D7 G'). Returns how many were named."""
    seqs = [[n for _, n in sorted(sd["chords"])] for sd in systems]
    filled = 0
    for si, sd in enumerate(systems):
        ch = sorted(sd["chords"])
        for i, (x, n) in enumerate(ch):
            if n is not None:
                continue
            before = ch[i - 1][1] if i else "^"
            after = ch[i + 1][1] if i + 1 < len(ch) else "$"
            found = set()
            for sj, other in enumerate(seqs):
                o = ["^"] + other + ["$"]
                for k in range(1, len(o) - 1):
                    if o[k] and o[k] not in "^$" and o[k - 1] == before and o[k + 1] == after and (before, after) != ("^", "$"):
                        if not (sj == si and k - 1 == i):
                            found.add(o[k])
            if len(found) == 1:
                ch[i] = (x, found.pop())
                filled += 1
        sd["chords"] = ch
    return filled


def _superscript_7(text: str, w: Word, x_off: int, comps) -> str:
    """'D⁷' is often read as 'Db?' or 'Db7': a small raised 7 taken for two signs. If only one
    mark follows the letter, it was the 7 (Gloria: D7 read as Db7)."""
    m = re.match(r"^([A-G])b[?7'!]$", text)
    if not m:
        return text
    x0, x1 = w.x - x_off, w.x - x_off + w.w
    marks = [c for c in comps if x0 - 2 <= c[0] and c[0] + c[2] <= x1 + 2 and c[3] >= 0.25 * max(1, w.h)]
    return m.group(1) + "7" if len(marks) <= 2 else text


def _erase_stems(band, sp):
    """White out thin vertical lines taller than a letter (note stems reaching up into the
    names: 141's G sits on one), so they don't spoil the reading."""
    if band.size == 0:
        return band
    ink = cv2.threshold(band, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    tall = cv2.morphologyEx(ink, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(3, int(1.7 * sp)))))
    # only thin ones: a stroke as wide as a letter's is part of the letter
    thin = cv2.morphologyEx(tall, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (max(2, int(0.25 * sp)), 1)))
    stems = cv2.subtract(tall, thin)
    if not stems.any():
        return band
    out = band.copy()
    out[stems > 0] = 255
    return out


def _read_chords(band, x_off, staff_x0, sp, near_staff=None):
    """Chord names are short and full of superscripts, so read the band three ways and vote.

    Returns (chords, capo). Many hymnals and songbooks print two rows: the chords as they sound
    (Eb) and under them, in brackets, the shapes to play with a capo ((D) = capo 1). Then the
    capo comes from the pairs, and each chord is taken from its bracketed shape, which reads far
    more reliably than a concert name with a small flat sign (813 The Servant Song, Paul 2026-11-27)."""
    comps = _components(band)
    passes = [_ocr_words(band, x_off, scale, psm, otsu) for scale, psm, otsu in ((2, 11, True), (3, 11, False), (2, 6, False))]
    # and each line of text on its own (reads bold or crowded names the page-wide passes miss)
    for a, b in _text_rows(band, sp):
        row = _ocr_words(band[max(0, a - 3):b + 3], x_off, 3, 7, False)
        for w in row:
            w.y += max(0, a - 3)
        passes.append(row)
    # past the clef (a name may start above it), and not running off the bottom of the band (the
    # top of a key signature, a stem or a high note)
    def reaches_staff(w):
        # a mark that runs on down to the staff (a key signature, a stem, a high note); a chord
        # name ends a little above it
        if near_staff is None or not w.h or w.y + w.h < band.shape[0] - 2:
            return False
        strip = near_staff[:, max(0, w.x - x_off):max(0, w.x - x_off) + max(1, w.w)]
        return strip.size > 0 and (strip < 128).any(axis=1).mean() > 0.6
    clear = lambda w: w.x + w.w / 2 >= staff_x0 + 3.5 * sp and not reaches_staff(w)
    words = [w for ws in passes for w in ws if clear(w)]
    paren = [w for w in words if ("(" in w.text or ")" in w.text) and len(w.text) >= 2]
    shape_y = None
    if len({round(w.x / (2 * sp)) for w in paren}) >= 2:
        shape_y = float(np.median([w.y + w.h / 2 for w in paren]))
    shapes_c = []
    cands = []
    named: list[Word] = []
    ys: list[float] = []      # where each candidate sat, to keep only the row of chord names
    for ws in passes:
        skip_to = -1
        for wi, w in enumerate(ws):
            if not clear(w):  # clef and key signature area
                continue
            nxt = ws[wi + 1] if wi + 1 < len(ws) else None
            if nxt and 0 <= nxt.x - (w.x + w.w) < 1.2 * sp and abs(nxt.y - w.y) < 0.4 * max(w.h, 1) \
                    and nxt.h >= 0.6 * w.h and re.fullmatch(r"[a-z]{3,}[.:]?", nxt.text) \
                    and len(set(nxt.text.strip(".:"))) >= 3:   # not note heads read as 'eee'/'ooo' 
                continue  # a word of a line of text ("A tempo"), not a chord
            if shape_y is not None and (abs(w.y + w.h / 2 - shape_y) < 0.9 * sp or "(" in w.text or ")" in w.text):
                m = _SHAPE.search(w.text)
                inner = (m.group(1) or m.group(2)) if m else None
                if inner:
                    pre = w.text[:w.text.find("(")] if "(" in w.text else ""
                    printed = normalise_chord(_superscript_7(pre, w, x_off, comps)) if len(pre) >= 1 else None
                    if printed:
                        # "Eb(D)": the chord and its shape side by side, as one word
                        cands.append((w.x, printed, 1.0))
                        x = w.x
                    else:
                        # the word may start with specks before the bracket: start at the bracket
                        x = w.x + int(w.w * len(pre) / len(w.text))
                    for c in split_chords(re.sub(r"[^A-Za-z0-9#/]", "", inner.replace("?", "7")))[:1]:
                        shapes_c.append((x, c, 1.0))
                continue
            if w.x < skip_to:  # the flat/sharp sign of the previous chord, read as its own word
                continue
            text, sign_end = _fix_accidental(w, x_off, comps, sp)
            text = _superscript_7(text, w, x_off, comps)
            if sign_end:
                skip_to = sign_end - 1
            names = split_chords(text)
            if shape_y is not None:
                names = names[:1]   # the shapes give the rest; a name split in two is a misread
            weight = 0.5 if text.endswith("/") else 1.0  # 'C/' is usually C7, but sometimes a 9
            for k, c in enumerate(names):
                cands.append((w.x + int(k * 2 * sp), c, weight))
                ys.append(w.y + w.h / 2)
            if names:
                named.append(w)
    if shape_y is None and len(cands) >= 3:
        # names read lower than the row of chord names: the top of a note or key signature
        row = float(np.median(ys))
        hh = float(np.median([w.h for w in named])) if named else sp
        cands = [c for c, y in zip(cands, ys) if abs(y - row) < 1.3 * hh]
        named = [w for w in named if abs(w.y + w.h / 2 - row) < 1.3 * hh]
    concert = _vote(cands, sp)
    shapes = _vote(shapes_c, sp, 2.0)   # bracketed words are read with more x jitter
    if len(shapes) < 2:
        return concert + _unread(comps, named, concert, x_off, sp, band.shape[0], staff_x0), None
    # pair each shape with the concert name over it; each pair votes for a capo fret
    pairs = []
    for x, shape in shapes:
        near = [c for c in concert if abs(c[0] - x) < 1.5 * sp]
        pairs.append((x, shape, min(near, key=lambda c: abs(c[0] - x)) if near else None))
    steps: dict[int, float] = {}
    for _, shape, c in pairs:
        a, b = _split_name(shape), _split_name(c[1]) if c else None
        if a and b and a[1] == b[1]:
            d = (b[0] - a[0]) % 12
            if len(c[1]) > 1 and c[1][1] in "#b":
                steps[d] = steps.get(d, 0) + 1
            else:
                # no sign read: it may have been a small flat or sharp that OCR dropped
                for e in (d - 1, d, d + 1):
                    steps[e % 12] = steps.get(e % 12, 0) + 0.5
    # "Capo 1" printed by the shapes settles it
    flat = [w.text for w in sorted(passes[0] + passes[1], key=lambda w: w.x)]
    flat = [w.text for w in sorted(passes[-1], key=lambda w: w.x)] if any(re.match(r"(?i)capo", w.text) for w in passes[-1]) else flat
    for i, t in enumerate(flat):
        m = re.match(r"(?i)^capo\W*(\d)?", t)
        if m:
            nxt = re.match(r"^\W*([\dilI|])\b", flat[i + 1]) if i + 1 < len(flat) else None
            n = m.group(1) or (nxt and nxt.group(1))
            n = "1" if n in ("i", "l", "I", "|") else n
            if n and 1 <= int(n) <= 7:
                steps[int(n)] = steps.get(int(n), 0) + 3
    return concert, dict(pairs=pairs, steps=steps, sp=sp)


def _pick_capo(steps: dict[int, float]) -> int | None:
    """The capo fret most shape/name pairs agree on (a printing slip or misread loses the vote)."""
    if not steps:
        return None
    ranked = sorted(steps.items(), key=lambda kv: -kv[1])
    capo, n = ranked[0]
    second = ranked[1][1] if len(ranked) > 1 else 0
    return capo if 1 <= capo <= 7 and n >= 2 and n >= 1.5 * second else None


def _with_capo(concert, info, capo):
    """Chords from the bracketed shapes moved up by the capo; names with no shape under them stay."""
    sp = info["sp"]
    out = [(c[0] if c else x, _from_pair(shape, capo, c[1] if c else None)) for x, shape, c in info["pairs"]]
    out = [(x, n) for x, n in out if n]
    xs = [x for x, _, _ in info["pairs"]]
    # a concert name with no shape under it stays as read (not the bits of one read in two)
    left = [c for c in concert if all(abs(c[0] - x) >= 2.5 * sp for x in xs)]
    left = [c for i, c in enumerate(left) if not (i and c[0] - left[i - 1][0] < 2.2 * sp)]
    out += [(x, _lost_sign(n, capo)) for x, n in left if all(abs(x - y) >= 2.2 * sp for y, _ in out)]
    return sorted(out)


def _lost_sign(name: str, capo: int) -> str:
    """A name read with no shape under it, on a page of capo shapes. Its shape would be a black
    key (E with capo 1 = D#) when the small flat was lost (Eb with capo 1 = D): put the flat back."""
    sp = _split_name(name)
    if sp is None or (len(name) > 1 and name[1] in "#b"):
        return name
    root, suffix, bass = sp
    if (root - capo) % 12 in (1, 3, 6, 8, 10) and (root - 1 - capo) % 12 not in (1, 3, 6, 8, 10):
        out = FLAT_NAMES[(root - 1) % 12] + suffix
        if bass is not None:
            out += "/" + FLAT_NAMES[(bass - 1) % 12]
        return out
    return name


def _system_measures(part):
    """Split the part's measures into systems using the new-system marks homr writes."""
    import music21 as m21
    groups: list[list] = []
    for mm in part.getElementsByClass("Measure"):
        new = any(getattr(sl, "isNew", False) for sl in mm.getElementsByClass(m21.layout.SystemLayout))
        if new or not groups:
            groups.append([])
        groups[-1].append(mm)
    return groups


def _top_line(mm):
    """The events of a staff with two voices (soprano and alto in a hymn) as one line: at each beat
    where something starts, the highest note (a rest only when nothing sounds there)."""
    at = {}
    for el in mm.recurse().notesAndRests:
        off = float(el.getOffsetInHierarchy(mm))
        cur = at.get(off)
        hi = max((p.midi for p in el.pitches), default=-1)
        if cur is None or hi > cur[0]:
            at[off] = (hi, el)
    return [el for _, (_, el) in sorted(at.items())]


def _estimate_x(measures, x0, x1, sp, top_line=False):
    """Rough x of each event in a system: engraved spacing grows with the log of the duration."""
    import math
    items = []  # (element, width)
    pos = 0.0
    xs = []
    for k, mm in enumerate(measures):
        pos += 1.5 if k else 0.0  # bar line padding
        for el in (_top_line(mm) if top_line else mm.recurse().notesAndRests):
            xs.append((el, pos, mm))
            d = max(float(el.quarterLength), 0.25)
            pos += max(0.7, 1.4 + 0.8 * math.log2(d))
    # the clef, then the key signature and a time signature take room before the first note
    start = x0 + 4.5 * sp
    if measures:
        first = measures[0]
        ks = first.keySignature or first.getContextByClass("KeySignature")
        start += 0.9 * sp * abs(getattr(ks, "sharps", 0) or 0)
        if first.timeSignature is not None:
            start += 1.5 * sp
    scale = (x1 - sp - start) / max(pos, 1e-6)
    return [(el, start + p * scale, mm) for el, p, mm in xs]


def _align(sylls, notes, sp):
    """Monotonic DP: match syllables to notes by x; either side may be skipped."""
    n, m = len(sylls), len(notes)
    skip_s, skip_n = 3.0, 1.2
    INF = 1e9
    D = np.full((n + 1, m + 1), INF)
    D[0, :] = np.arange(m + 1) * skip_n
    D[:, 0] = np.arange(n + 1) * skip_s
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            c = min(abs(sylls[i - 1].x - notes[j - 1][1]) / (4 * sp), 3.0)
            D[i, j] = min(D[i - 1, j - 1] + c, D[i - 1, j] + skip_s, D[i, j - 1] + skip_n)
    pairs, i, j = [], n, m
    while i > 0 and j > 0:
        c = min(abs(sylls[i - 1].x - notes[j - 1][1]) / (4 * sp), 3.0)
        if np.isclose(D[i, j], D[i - 1, j - 1] + c):
            pairs.append((i - 1, j - 1)); i -= 1; j -= 1
        elif np.isclose(D[i, j], D[i - 1, j] + skip_s):
            i -= 1
        else:
            j -= 1
    return pairs[::-1]


def apply_text_layers(score, systems, warnings: list[str]) -> None:
    import music21 as m21
    parts = list(score.parts)
    if not parts:
        return
    part = parts[0]
    groups = _system_measures(part)
    grand = False
    if len(parts) > 1:
        # a hymn or piano score: the words sit under the top staff of each system (between the
        # staves); the text read under every other staff is left out
        if not all(isinstance(p, m21.stream.PartStaff) for p in parts) or len(systems) != len(parts) * len(groups):
            return
        systems = systems[::len(parts)]
        grand = True
    if len(groups) != len(systems):
        warnings.append(f"Chord names and lyrics were skipped: found {len(systems)} staves but "
                        f"{len(groups)} lines of music.")
        return
    cut = next((i for i, sd in enumerate(systems) if i and sd.get("new_song")), None)
    if cut is not None:
        # the page goes on with another song: keep only this one
        first_bar = groups[cut][0].number
        n = len([mm for g in groups[:cut] for mm in g])
        for p in parts:
            for mm in list(p.getElementsByClass("Measure"))[n:]:
                p.remove(mm)
        groups, systems = groups[:cut], systems[:cut]
        warnings.append(f"The page goes on with another song (from bar {first_bar}); it was left out. "
                        "Import that song on its own to play it.")
    n_syl, n_left, n_chords, n_skip = 0, 0, 0, 0
    for sysd, measures in zip(systems, groups):
        sp = sysd["sp"]
        est = _estimate_x(measures, sysd["x0"], sysd["x1"], sp, top_line=grand)
        notes = [(el, x, mm) for el, x, mm in est if el.isNote or el.isChord]
        singable = [n for n in notes if not (n[0].tie is not None and n[0].tie.type in ("stop", "continue"))]
        sylls = list(sysd["syllables"])
        # a verse number ("1.", read as "l" or "1,&6.") before the first word is not a syllable
        while len(sylls) > len(singable) and sylls and re.match(r"^[\dlI|&,.]+$", sylls[0].text):
            sylls.pop(0)
        # If the counts agree, take them in order; otherwise align by position.
        pairs = list(zip(range(len(sylls)), range(len(singable)))) if len(sylls) == len(singable) \
            else _align(sylls, singable, sp)
        if len(sylls) != len(singable) and len(pairs) >= 4:
            # the estimate is rough: fit it to where the words matched, then match again
            ex = np.array([singable[j][1] for _, j in pairs]); wx = np.array([sylls[i].x for i, _ in pairs])
            a, b = np.polyfit(ex, wx, 1)
            if 0.7 < a < 1.4:
                fit = lambda x: a * x + b
                est = [(el, fit(x), mm) for el, x, mm in est]
                notes = [(el, fit(x), mm) for el, x, mm in notes]
                singable = [(el, fit(x), mm) for el, x, mm in singable]
                pairs = _align(sylls, singable, sp)
        anchors = []
        for si, ni in pairs:
            el, _, mm = singable[ni]
            s = sylls[si]
            el.lyrics = [m21.note.Lyric(text=s.text, syllabic=s.syllabic)]
            anchors.append((s.x, el, mm))
            n_syl += 1
        n_left += len(sylls) - len(pairs)
        for x, name in sysd["chords"]:
            pool = anchors or [(nx, el, mm) for el, nx, mm in notes]
            if not pool:
                n_skip += 1
                continue
            _, el, meas = min(pool, key=lambda a: abs(a[0] - x))
            if anchors and est and min(abs(a[0] - x) for a in anchors) > 2 * sp:
                # no word under it (a held or slurred note, or an intro over rests): the nearest
                # note or rest
                _, el, meas = min(((nx, e, m) for e, nx, m in est), key=lambda a: abs(a[0] - x))
            try:
                cs = m21.harmony.ChordSymbol(m21_figure(name))
            except Exception:
                n_skip += 1
                continue
            cs.writeAsChord = False
            # Show the name as printed (e.g. "m/G", "maj7/G"); many apps ignore <bass> otherwise.
            root_len = 2 if len(name) > 1 and name[1] in "#b" else 1
            cs.chordKindStr = name[root_len:]
            meas.insert(el.getOffsetBySite(el.activeSite) if el.activeSite is meas else el.getOffsetInHierarchy(meas), cs)
            n_chords += 1
    if n_syl and not grand and (part.partName or "").startswith("Piano"):
        # A single melody line with lyrics is a vocal line (lead sheet, hymn): don't call it piano.
        for inst in list(part.recurse().getElementsByClass("Instrument")):
            inst.activeSite.remove(inst)
        part.insert(0, m21.instrument.Vocalist())
        old = part.partName
        part.partName = "Voice"
        warnings[:] = [w for w in warnings if not w.startswith(f"Instrument for '{old}'")]
        warnings.append("Read as a vocal melody because it has lyrics (a guess). Change the instrument if needed.")
    if n_syl:
        warnings.append(f"Read {n_syl} lyric syllables" + (f" ({n_left} more words couldn't be matched to notes)" if n_left else "")
                        + ". Check that each sits under the right note.")
    capos = [c for c in (sd.get("capo") for sd in systems) if c]
    if n_chords and capos:
        capo = max(set(capos), key=capos.count)
        if score.metadata is None:
            score.insert(0, m21.metadata.Metadata())
        # the app opens the song with this capo, so the chords show as the bracketed shapes
        score.metadata.addCustom(PRINTED_CAPO, str(capo))
        warnings.append(f"The chords are printed as they sound, with the shapes for capo {capo} in brackets: "
                        f"the song opens with capo {capo}, so the chords show as those shapes. "
                        "Set the capo to 0 to see them as they sound.")
    if n_chords:
        from .backing import add_backing_chords
        add_backing_chords(score)
        warnings.append(f"Read {n_chords} chord names" + (f" ({n_skip} more couldn't be placed)" if n_skip else "")
                        + ". Chord reading is new: check the names, especially 7ths and slash chords.")
