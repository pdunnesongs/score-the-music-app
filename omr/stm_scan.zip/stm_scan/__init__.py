"""The engine's scan code, unpacked on the phone (see app/public/omr/device.py)."""
