"""Make a scanned sheet playable as melody + chords (Paul, 2026-11-26: hymnal pages brought in from
MobileSheets, e.g. "509 Take My Hands", should play the tune and its chords).

Hymnals print the tune with three more parts under it (soprano and alto on the treble staff, tenor and
bass on the bass staff) and seldom any chord names. From the scanned score this adds:

- a "Melody" part: the top line of the top staff (the highest note at each new note, held notes kept);
- chord names on the melody, worked out from all the parts sounding on each beat (when the page had no
  chord names of its own), and the "Backing chords" part that playback switches on and off;
- the parts as printed stay, renamed "Harmony (as printed)", so they can be played too.
"""
from __future__ import annotations

from fractions import Fraction

MELODY_NAME = "Melody"
HARMONY_NAME = "Harmony (as printed)"

# chord qualities: intervals above the root, the name suffix, and a small preference (simple chords win ties)
QUALITIES = [
    ((0, 4, 7), "", 0.06),
    ((0, 3, 7), "m", 0.05),
    ((0, 4, 7, 10), "7", 0.0),
    ((0, 3, 7, 10), "m7", 0.0),
    ((0, 4, 7, 11), "maj7", -0.02),
    ((0, 3, 6), "dim", -0.04),
    ((0, 5, 7), "sus4", -0.04),
    ((0, 2, 7), "sus2", -0.06),
    ((0, 4, 8), "aug", -0.08),
    ((0, 4), "", -0.03),        # bare third or fifth: read as the plain triad
    ((0, 3), "m", -0.04),
    ((0, 7), "", -0.05),
]
SHARP_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
FLAT_NAMES = ["C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B"]


def _q(x) -> Fraction:
    return Fraction(x).limit_denominator(96)


def _events(stream, measures):
    """(start, end, midi) of every note in a part, in quarter notes from the start of the piece."""
    out = []
    for mm in measures:
        base = _q(mm.offset)
        for n in mm.recurse().notes:
            if n.duration.isGrace or n.quarterLength == 0:
                continue
            st = base + _q(n.getOffsetInHierarchy(mm))
            en = st + _q(n.quarterLength)
            for p in n.pitches:
                out.append((st, en, p.midi))
    # notes tied over the bar join up again
    out.sort()
    return out


def _name(root: int, suffix: str, bass: int | None, flats: bool) -> str:
    names = FLAT_NAMES if flats else SHARP_NAMES
    s = names[root] + suffix
    if bass is not None and bass != root:
        s += "/" + names[bass]
    return s


def best_chord(weights: dict[int, float], bass_pc: int | None, prev: tuple | None = None):
    """Name the chord for one beat: weights = how long each pitch class sounds. Returns (root, suffix, bass) or None."""
    total = sum(weights.values())
    if total <= 0:
        return None
    best, best_score = None, -1e9
    for root in range(12):
        for ivs, suffix, pref in QUALITIES:
            tones = {(root + i) % 12 for i in ivs}
            inside = sum(w for pc, w in weights.items() if pc in tones)
            outside = total - inside
            missing = sum(1 for t in tones if weights.get(t, 0) <= 0)
            score = (inside - 1.2 * outside) / total - 0.22 * missing + pref
            if bass_pc == root:
                score += 0.12
            elif bass_pc is not None and bass_pc in tones:
                score += 0.03
            if prev is not None and prev[0] == root and prev[1] == suffix:
                score += 0.05      # keep the chord through passing notes
            if score > best_score:
                best, best_score = (root, suffix, tones), score
    root, suffix, tones = best
    bass = bass_pc if bass_pc is not None and bass_pc != root and bass_pc in tones else None
    return root, suffix, bass


def _beat_length(ts) -> Fraction:
    if ts is None:
        return Fraction(1)
    if ts.numerator in (6, 9, 12) and ts.denominator == 8:
        return Fraction(3, 2)
    return _q(4 / ts.denominator)


def add_melody_and_chords(score, warnings: list[str]) -> bool:
    """Add a Melody part (with chord names and backing) in front of the printed parts. Returns True if added."""
    import music21 as m21
    from .backing import add_backing_chords, BACKING_NAME

    parts = [p for p in score.parts if p.partName != BACKING_NAME]
    if not parts:
        return False
    top = parts[0]
    top_measures = list(top.getElementsByClass("Measure"))
    if not top_measures:
        return False
    printed_names = list(score.recurse().getElementsByClass(m21.harmony.ChordSymbol))
    has_names = len(printed_names) * 2 >= len(top_measures)
    if printed_names and not has_names:
        # a stray name or two read from marks on the page (hymnals seldom print chords): use the
        # chords worked out from the parts instead
        for cs in printed_names:
            cs.activeSite.remove(cs)
        warnings[:] = [w for w in warnings if not w.startswith("Read ") or "chord names" not in w]
    all_events = [(_events(p, list(p.getElementsByClass("Measure")))) for p in parts]
    top_events = all_events[0]
    if not top_events:
        return False
    polyphonic = len(parts) > 1 or any(a[0] == b[0] for a, b in zip(top_events, top_events[1:]))
    if not polyphonic:
        return False      # a single tune line: it plays as it is (with its chord names, if any)

    # ---- melody: the skyline of the top staff ----
    by_start: dict[Fraction, list] = {}
    for st, en, midi in top_events:
        by_start.setdefault(st, []).append((midi, en))
    melody = []     # [start, end, midi]
    for st in sorted(by_start):
        midi, en = max(by_start[st])
        if melody and melody[-1][1] > st:
            held = melody[-1]
            if midi < held[2]:
                continue                  # an inner voice moves under a held tune note
            held[1] = st                  # the tune moves on
        melody.append([st, en, midi])

    # ---- chords: what sounds on each beat ----
    flats = False
    ks = top_measures[0].getContextByClass(m21.key.KeySignature)
    if ks is not None and ks.sharps < 0:
        flats = True
    beats = []     # (start, end)
    for mm in top_measures:
        ts = mm.getContextByClass(m21.meter.TimeSignature)
        bl = _beat_length(ts)
        st, en = _q(mm.offset), _q(mm.offset) + _q(mm.duration.quarterLength)
        b = st
        while b < en:
            beats.append((b, min(en, b + bl)))
            b += bl
    every = [e for evs in all_events for e in evs]
    chords = []    # (start, (root, suffix, bass))
    prev = None
    for b0, b1 in beats:
        w: dict[int, float] = {}
        sounding = []
        for st, en, midi in every:
            ov = min(en, b1) - max(st, b0)
            if ov > 0:
                # a note struck on the beat counts more than one held over or passing
                w[midi % 12] = w.get(midi % 12, 0) + float(ov) * (1.5 if st == b0 else 1.0)
                sounding.append((st > b0, midi))
        if not w:
            prev = None
            continue
        bass = min((m for late, m in sounding if not late), default=min(m for _, m in sounding)) % 12
        ch = best_chord(w, bass, prev)
        if ch is None:
            continue
        if prev is None or ch != prev:
            chords.append((b0, ch))
        prev = ch

    # ---- build the Melody part, bar by bar like the printed ones ----
    mel = m21.stream.Part()
    mel.partName = MELODY_NAME
    inst = m21.instrument.Vocalist() if any(n.lyrics for n in top.recurse().notes) else m21.instrument.Piano()
    inst.partName = MELODY_NAME
    mel.insert(0, inst)
    lyrics_at = {}
    for mm in top_measures:
        for n in mm.recurse().notes:
            if n.lyrics:
                lyrics_at.setdefault(_q(mm.offset) + _q(n.getOffsetInHierarchy(mm)), n.lyrics)
    mi, ci = 0, 0
    for k, mm in enumerate(top_measures):
        new = m21.stream.Measure(number=mm.number)
        if k == 0:
            ts = mm.getContextByClass(m21.meter.TimeSignature)
            if ts is not None:
                new.timeSignature = m21.meter.TimeSignature(ts.ratioString)
            if ks is not None:
                new.keySignature = m21.key.KeySignature(ks.sharps)
            new.clef = m21.clef.TrebleClef()
        else:
            if mm.timeSignature is not None:
                new.timeSignature = m21.meter.TimeSignature(mm.timeSignature.ratioString)
            if mm.keySignature is not None:
                new.keySignature = m21.key.KeySignature(mm.keySignature.sharps)
        st, en = _q(mm.offset), _q(mm.offset) + _q(mm.duration.quarterLength)
        pos = st
        while mi < len(melody) and melody[mi][0] < en:
            a, b, midi = melody[mi]
            a = max(a, st)
            if a > pos:
                new.insert(float(pos - st), m21.note.Rest(quarterLength=float(a - pos)))
            end = min(b, en)
            if end > a:
                n = m21.note.Note(midi=midi, quarterLength=float(end - a))
                if b > en:
                    n.tie = m21.tie.Tie("start")
                if a == melody[mi][0] and a in lyrics_at:
                    for ly in lyrics_at[a]:
                        n.lyrics.append(m21.note.Lyric(text=ly.text, number=ly.number, syllabic=ly.syllabic))
                new.insert(float(a - st), n)
                pos = end
            if b > en:
                melody[mi][0] = en      # carry the rest of the note into the next bar
                break
            mi += 1
        if pos < en:
            new.insert(float(pos - st), m21.note.Rest(quarterLength=float(en - pos)))
        if not has_names:
            while ci < len(chords) and chords[ci][0] < en:
                at, (root, suffix, bass) = chords[ci]
                if at >= st:
                    cs = m21.harmony.ChordSymbol(_name(root, suffix, bass, flats))
                    cs.writeAsChord = False
                    new.insert(float(at - st), cs)
                ci += 1
        mel.append(new)
    if has_names:
        # move the chord names read from the page onto the melody, so the backing follows them
        for mm, new in zip(top_measures, mel.getElementsByClass("Measure")):
            for cs in list(mm.recurse().getElementsByClass(m21.harmony.ChordSymbol)):
                off = cs.getOffsetInHierarchy(mm)
                cs.activeSite.remove(cs)
                new.insert(off, cs)
    for p in parts:
        p.partName = HARMONY_NAME
        for i in p.recurse().getElementsByClass(m21.instrument.Instrument):
            i.partName = HARMONY_NAME
    printed = list(score.parts)
    for p in printed:
        score.remove(p)
    score.insert(0, mel)
    for p in printed:
        score.insert(0, p)
    # Backing part from the melody's chord names (replace one made earlier from the printed names)
    for p in list(score.parts):
        if p.partName == BACKING_NAME:
            score.remove(p)
    add_backing_chords(score)
    if not has_names:
        warnings.append("Chord names were worked out from the printed parts (a guess): check them, "
                        "especially where the harmony moves quickly.")
    warnings[:] = [w for w in warnings if not (w.startswith("Instrument for '") and "is a guess (piano)" in w)]
    warnings.append("Melody is the top line of the top staff; the printed parts are kept as "
                    f"\"{HARMONY_NAME}\" and can be played too.")
    return True
