"""Tiny digit classifier for tab fret numbers, trained on digits rendered from common sans fonts."""
import cv2, numpy as np, glob
from PIL import Image, ImageDraw, ImageFont
W, H = 16, 24
FONTS = [f for pat in ["DejaVuSans*.ttf", "LiberationSans*.ttf", "FreeSans*.ttf", "DejaVuSansMono*.ttf", "LiberationMono*.ttf", "DejaVuSerif*.ttf", "LiberationSerif*.ttf"]
         for f in glob.glob("/usr/share/fonts/truetype/*/" + pat)]
hog = cv2.HOGDescriptor((W, H), (8, 8), (4, 4), (4, 4), 9)

def normalise(bin_img):
    """bin_img: uint8, ink=255. Crop to ink, fit into W x H keeping aspect."""
    ys, xs = np.nonzero(bin_img)
    if len(xs) == 0: return np.zeros((H, W), np.uint8)
    c = bin_img[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    h, w = c.shape; s = min((W - 2) / w, (H - 2) / h)
    c = cv2.resize(c, (max(1, round(w * s)), max(1, round(h * s))), interpolation=cv2.INTER_AREA)
    out = np.zeros((H, W), np.uint8); y0 = (H - c.shape[0]) // 2; x0 = (W - c.shape[1]) // 2
    out[y0:y0 + c.shape[0], x0:x0 + c.shape[1]] = c
    return out

def feat(norm):
    return np.concatenate([hog.compute(norm).ravel(), [norm.shape[0] / norm.shape[1]]])

def train_set():
    X, y = [], []
    rng = np.random.default_rng(1)
    for f in FONTS:
        for size in (28, 40, 56):
            font = ImageFont.truetype(f, size)
            for d in "0123456789":
                for k in range(3):
                    im = Image.new("L", (size * 2, size * 2), 0)
                    ImageDraw.Draw(im).text((size // 2, size // 4), d, fill=255, font=font)
                    a = np.array(im)
                    if k == 1: a = cv2.dilate(a, np.ones((2, 2), np.uint8))
                    if k == 2: a = cv2.GaussianBlur(a, (3, 3), 0)
                    a = (a > 100).astype(np.uint8) * 255
                    X.append(feat(normalise(a))); y.append(int(d))
    return np.array(X, np.float32), np.array(y, np.int32)

MODEL = __import__("pathlib").Path(__file__).with_name("digits_model.npz")


class DigitReader:
    def __init__(self):
        if MODEL.exists():
            d = np.load(MODEL); X, y = d["X"], d["y"]
        else:
            X, y = train_set()
            np.savez_compressed(MODEL, X=X, y=y)
        self.knn = cv2.ml.KNearest_create(); self.knn.train(X, cv2.ml.ROW_SAMPLE, y)
    def read(self, bin_crop):
        _, res, _, dist = self.knn.findNearest(np.array([feat(normalise(bin_crop))], np.float32), 3)
        return int(res[0, 0]), float(dist[0, 0])
