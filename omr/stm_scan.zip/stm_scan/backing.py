"""Turn chord names into a quiet backing track that playback can switch on and off.

Adds a part named "Backing chords" (piano) under the melody: each chord is held until the next chord
name, with the root in the bass and the chord in close position above it. The app hides this part
from the printed score and gives it its own on/off switch.
"""
from __future__ import annotations

BACKING_NAME = "Backing chords"


def _voicing(cs):
    import music21 as m21
    root = cs.root()
    bass_pc = (cs.bass() or root).pitchClass
    bass = m21.pitch.Pitch(midi=36 + bass_pc if bass_pc >= 4 else 48 + bass_pc)  # E2..D#3
    tones = []
    for p in cs.pitches:
        midi = 55 + (p.pitchClass - 7) % 12  # G3..F#4
        if midi not in tones:
            tones.append(midi)
    return [bass] + [m21.pitch.Pitch(midi=t) for t in sorted(tones)]


def add_backing_chords(score) -> bool:
    import music21 as m21
    if not score.parts:
        return False
    melody = score.parts[0]
    measures = list(melody.getElementsByClass("Measure"))
    events = []  # (measure index, offset, ChordSymbol)
    for k, mm in enumerate(measures):
        for cs in mm.recurse().getElementsByClass(m21.harmony.ChordSymbol):
            events.append((k, float(cs.getOffsetInHierarchy(mm)), cs))
    if not events:
        return False
    events.sort(key=lambda e: (e[0], e[1]))
    # drop chords sharing a beat with the next one (keep the later, it's what is heard)
    dedup = []
    for e in events:
        if dedup and dedup[-1][0] == e[0] and dedup[-1][1] == e[1]:
            dedup[-1] = e
        else:
            dedup.append(e)
    part = m21.stream.Part()
    part.partName = BACKING_NAME
    inst = m21.instrument.Piano()
    inst.partName = BACKING_NAME
    part.insert(0, inst)
    current = None
    ei = 0
    for k, mm in enumerate(measures):
        new = m21.stream.Measure(number=mm.number)
        bar_len = mm.barDuration.quarterLength if mm.barDuration else mm.duration.quarterLength
        if k == 0:
            ts = mm.getContextByClass(m21.meter.TimeSignature)
            if ts:
                new.timeSignature = m21.meter.TimeSignature(ts.ratioString)
            ks = mm.getContextByClass(m21.key.KeySignature)
            if ks:
                new.keySignature = m21.key.KeySignature(ks.sharps)
            bar_len = mm.duration.quarterLength or bar_len
        if new.timeSignature is None and mm.timeSignature is not None:  # also a time change mid-song
            new.timeSignature = m21.meter.TimeSignature(mm.timeSignature.ratioString)
        if k == 0 and new.keySignature is None and mm.keySignature is not None:
            new.keySignature = m21.key.KeySignature(mm.keySignature.sharps)
        changes = [(0.0, current)]
        while ei < len(dedup) and dedup[ei][0] == k:
            _, off, cs = dedup[ei]
            if off == 0.0:
                changes[0] = (0.0, cs)
            else:
                changes.append((off, cs))
            current = cs
            ei += 1
        length = mm.duration.quarterLength or bar_len
        for i, (off, cs) in enumerate(changes):
            end = changes[i + 1][0] if i + 1 < len(changes) else length
            dur = end - off
            if dur <= 0:
                continue
            if cs is None:
                el = m21.note.Rest(quarterLength=dur)
            else:
                el = m21.chord.Chord(_voicing(cs), quarterLength=dur)
                el.volume.velocity = 60
            new.insert(off, el)
        part.append(new)
    score.insert(0, part)
    return True
